USE [ShopperStock]
GO

/****** Object:  Table [dbo].[S_CategoryMaster]    Script Date: 31-05-2024 00:56:57 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[S_CategoryMaster](
	[CategoryID] [int] IDENTITY(1,1) NOT NULL,
	[CategoryCode] [int] NOT NULL,
	[CategoryName] [varchar](70) NULL,
	[CategoryDesc] [varchar](50) NULL,
	[EntryDateTime] [smalldatetime] NULL,
	[ModifiedDate] [smalldatetime] NULL,
 CONSTRAINT [PK__S_CategoryMas__6379261FD781D3D5] PRIMARY KEY CLUSTERED 
(
	[CategoryCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


