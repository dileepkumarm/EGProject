USE [ShopperStock]
GO

/****** Object:  Table [dbo].[S_Customer]    Script Date: 31-05-2024 00:57:02 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[S_Customer](
	[PLID] [int] IDENTITY(1,1) NOT NULL,
	[PLCode] [int] NOT NULL,
	[PLName] [varchar](100) NULL,
	[PLEmail] [varchar](100) NULL,
	[PLAddress1] [varchar](100) NULL,
	[PLAddress2] [varchar](100) NULL,
	[PLCity] [varchar](50) NULL,
	[PLState] [varchar](50) NULL,
	[PLPIN] [int] NULL,
	[PLPhone] [varchar](100) NULL,
	[PLEntryDate] [datetime] NULL,
	[PLModifiedDate] [datetime] NULL,
 CONSTRAINT [PK_S_PartyLedger] PRIMARY KEY CLUSTERED 
(
	[PLCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


