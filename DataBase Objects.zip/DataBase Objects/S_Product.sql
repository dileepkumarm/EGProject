USE [ShopperStock]
GO

/****** Object:  Table [dbo].[S_Product]    Script Date: 31-05-2024 00:57:07 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[S_Product](
	[ProductID] [int] IDENTITY(1,1) NOT NULL,
	[ProductCode] [int] NOT NULL,
	[ProductName] [varchar](100) NULL,
	[ProductDesc] [varchar](100) NULL,
	[ProductcategoryCode] [varchar](10) NULL,
	[ProductQty] [int] NULL,
	[ProductSalesRate] [decimal](12, 2) NULL,
	[ProductEntryDate] [datetime] NULL,
	[ProductModifiedDate] [datetime] NULL,
 CONSTRAINT [PK_S_ProductMast] PRIMARY KEY CLUSTERED 
(
	[ProductCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


