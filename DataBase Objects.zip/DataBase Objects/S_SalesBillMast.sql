USE [ShopperStock]
GO

/****** Object:  Table [dbo].[S_SalesBillMast]    Script Date: 31-05-2024 00:57:13 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[S_SalesBillMast](
	[SBMastCode] [int] IDENTITY(1,1) NOT NULL,
	[SBMastPartyID] [varchar](10) NULL,
	[SBMastPartyName] [varchar](200) NULL,
	[SBMastProductCode] [varchar](10) NULL,
	[SBMastProductName] [varchar](200) NULL,
	[SBMastQty] [int] NOT NULL,
	[SBMastEntryDate] [datetime] NULL,
	[SBMastModifiedDate] [datetime] NULL,
	[SBMastInvoiceAmt] [decimal](12, 2) NULL,
	[SBMastSalesRate] [decimal](12, 2) NULL,
	[SBMastDisc] [decimal](12, 2) NULL,
	[SBMastTax] [decimal](12, 2) NULL,
 CONSTRAINT [PK_S_SalesBillMast] PRIMARY KEY CLUSTERED 
(
	[SBMastCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


