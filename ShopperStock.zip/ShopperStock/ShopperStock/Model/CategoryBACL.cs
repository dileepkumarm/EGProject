﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;


namespace ShopperStock.Model
{
   sealed class CategoryBACL
    {
        private readonly ConfigSettings objConfig = new ConfigSettings();
        private readonly  Ihelper objutilFun = new UtilityFunction();
        private ConnectionProp objConProp = new ConnectionProp();
        public void AddCategory(CategoryProp objProp)
        {
            SqlCommand cmd = new SqlCommand();
            SqlConnection UserCon = new SqlConnection();
            try
            {

                objConProp = objConfig.GetConnectionStringConfiguration();
                UserCon.ConnectionString = objConProp.MainConnection;
                cmd.Connection = UserCon;
                int CategoryCode = GenerateCategoryCode();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "Insert Into  S_CategoryMaster (CategoryCode,CategoryName,CategoryDesc, EntryDateTime)  values(@CategoryCode, @CategoryName,@CategoryDesc,  @EntryDateTime)";
                cmd.Parameters.Add("@CategoryCode", SqlDbType.Int).Value = CategoryCode;
                cmd.Parameters.Add("@CategoryName", SqlDbType.VarChar).Value = objProp.CategoryName;
                cmd.Parameters.Add("@CategoryDesc", SqlDbType.VarChar).Value = objProp.CategoryDesc;
                cmd.Parameters.Add("@EntryDateTime", SqlDbType.SmallDateTime).Value = DateTime.Now;

                try
                {
                    UserCon.Open();
                    cmd.ExecuteNonQuery();
                    UserCon.Close();

                }
                catch (Exception ex)
                {
                    objProp.ErrorOccured = true;
                    objutilFun.WriteErrorLog("CategoryBACL", " Inner AddCategory", ex.Message);
                    throw ex;
                }
                finally
                {
                    UserCon.Close();
                }
            }
            catch (Exception ex)
            {
                objProp.ErrorOccured = true;
                objutilFun.WriteErrorLog("CategoryBACL", "Outer AddCategory", ex.Message);
            }
        }

        public void EditCategory(CategoryProp objProp)
        {
            SqlCommand cmd = new SqlCommand();
            SqlConnection UserCon = new SqlConnection();
            try
            {

                objConProp = objConfig.GetConnectionStringConfiguration();
                UserCon.ConnectionString = objConProp.MainConnection;
                cmd.Connection = UserCon;

                cmd.CommandText = "Update  S_CategoryMaster set CategoryDesc=@CategoryDesc,CategoryName=@CategoryName,  ModifiedDate = @ModifiedDate where CategoryCode= @CategoryCode ";
                cmd.Parameters.Add("@CategoryCode", SqlDbType.Int).Value = objProp.CategoryCode;
                cmd.Parameters.Add("@CategoryName", SqlDbType.VarChar).Value = objProp.CategoryName;
                cmd.Parameters.Add("@CategoryDesc", SqlDbType.VarChar).Value = objProp.CategoryDesc;
  
                cmd.Parameters.Add("@ModifiedDate", SqlDbType.SmallDateTime).Value = DateTime.Now;

                try
                {
                    UserCon.Open();
                    cmd.ExecuteNonQuery();
                    UserCon.Close();

                }
                catch (Exception ex)
                {
                    objProp.ErrorOccured = true;
                    objutilFun.WriteErrorLog("CategoryBACL", "Inner method EditCategory", ex.Message);
                }
                finally
                {
                    UserCon.Close();
                }
            }
            catch (Exception ex)
            {
                objProp.ErrorOccured = true;
                objutilFun.WriteErrorLog("CategoryBACL", "Outer method EditCategory", ex.Message);
                throw ex;
            }
        }
        public CategoryProp GetCategory(CategoryProp objHProp)
        {
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter dad = new SqlDataAdapter();
            DataTable ds = new DataTable();
            SqlConnection UserCon = new SqlConnection();
            CategoryProp objCategoryProp = new CategoryProp();

            objConProp = objConfig.GetConnectionStringConfiguration();
            UserCon.ConnectionString = objConProp.MainConnection;
            cmd.Connection = UserCon;

            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select CategoryCode,CategoryName,CategoryDesc from S_CategoryMaster where CategoryCode= @CategoryCode";
            cmd.Parameters.Add("@CategoryCode", SqlDbType.VarChar).Value = objHProp.CategoryCode;
            dad.SelectCommand = cmd;

            try
            {
                UserCon.Open();
                cmd.ExecuteNonQuery();
                UserCon.Close();
                dad.Fill(ds);
                if (ds.Rows.Count > 0)
                {
                    objCategoryProp = SetCategory(ds);
                }
            }
            catch (Exception ex)
            {
                objutilFun.WriteErrorLog("CategoryBACL", "GetCategory", ex.Message);
                objCategoryProp.ErrorOccured = true;
            }
            finally
            {
                UserCon.Close();
            }

            return objCategoryProp;
        }

        public void DeleteCategory(CategoryProp objProp)
        {
            SqlCommand cmd = new SqlCommand();
            SqlConnection UserCon = new SqlConnection();
            try
            {

                objConProp = objConfig.GetConnectionStringConfiguration();
                UserCon.ConnectionString = objConProp.MainConnection;
                cmd.Connection = UserCon;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "Delete from S_CategoryMaster Where CategoryCode= @CategoryCode";
                cmd.Parameters.Add("@CategoryCode", SqlDbType.Int).Value = objProp.CategoryCode;
                try
                {
                    UserCon.Open();
                    cmd.ExecuteNonQuery();
                    UserCon.Close();

                }
                catch (Exception ex)
                {
                    objProp.ErrorOccured = true;
                    objutilFun.WriteErrorLog("CategoryrBACL", " DeleteCategory", ex.Message);
                    throw ex;
                }
                finally
                {
                    UserCon.Close();
                }
            }
            catch (Exception ex)
            {
                objProp.ErrorOccured = true;
                objutilFun.WriteErrorLog("CategoryrBACL", "DeleteCategory", ex.Message);
            }
        }
        public List<CategoryProp> GetAllCategory()
        {
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter dad = new SqlDataAdapter();
            DataTable ds = new DataTable();
            SqlConnection UserCon = new SqlConnection();
            List<CategoryProp> lstCategoryProp = new List<CategoryProp>();

            objConProp = objConfig.GetConnectionStringConfiguration();
            UserCon.ConnectionString = objConProp.MainConnection;
            cmd.Connection = UserCon;

            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select CategoryCode,CategoryName,CategoryDesc from S_CategoryMaster";
            dad.SelectCommand = cmd;

            try
            {
                UserCon.Open();
                cmd.ExecuteNonQuery();
                UserCon.Close();
                dad.Fill(ds);
                if (ds.Rows.Count > 0)
                {
                    lstCategoryProp = SetAllCategory(ds);
                }
            }
            catch (Exception ex)
            {
                objutilFun.WriteErrorLog("CategoryBACL", "GetAllCategory", ex.Message);
                return lstCategoryProp;
            }
            finally
            {
                UserCon.Close();
            }

            return lstCategoryProp;
        }



        private int GenerateCategoryCode()
        {
            int CategoryCode;
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter dad = new SqlDataAdapter();
            DataTable ds = new DataTable();
            SqlConnection UserCon = new SqlConnection();

            objConProp = objConfig.GetConnectionStringConfiguration();
            UserCon.ConnectionString = objConProp.MainConnection;
            cmd.Connection = UserCon;

            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select  Isnull(max(CategoryCode),0) as CategoryCode  from S_CategoryMaster";
            dad.SelectCommand = cmd;

            try
            {
                UserCon.Open();
                cmd.ExecuteNonQuery();
                UserCon.Close();
                dad.Fill(ds);
                if (ds.Rows.Count > 0)
                {
                    CategoryCode = Convert.ToInt32(ds.Rows[0]["CategoryCode"])+1;
                }
                else
                {
                    CategoryCode = 1;
                }
            }
            catch (Exception ex)
            {
                objutilFun.WriteErrorLog("CategoryBACL", "GenerateCategoryCode", ex.Message);
                throw ex;
            }
            finally
            {
                UserCon.Close();
            }

            return CategoryCode;
        }
        public DataSet GetCategorySearchQueryData(CategoryProp objProp)
        {
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter dad = new SqlDataAdapter();
            DataSet ds = new DataSet();
            string empty;
            SqlConnection UserCon = new SqlConnection();

            objConProp = objConfig.GetConnectionStringConfiguration();
            UserCon.ConnectionString = objConProp.MainConnection;
            cmd.Connection = UserCon;

            var datetime = DateTime.Now;
            var entrydate = datetime.Date;

            cmd.CommandType = CommandType.Text;
            cmd.Parameters.Add("@SearchText", SqlDbType.VarChar, 50).Value = objProp.SearchText;
            cmd.Parameters.Add("@entrydate", SqlDbType.SmallDateTime, 50).Value = entrydate;

            string sqlMainQuery = "SELECT CategoryCode,CategoryName,CategoryDesc  from S_CategoryMaster  where 1=1 ";
            switch (objProp.SearchIndex)
            {
                case 0:
                    cmd.CommandText = sqlMainQuery + " AND LEFT(CONVERT(VARCHAR, EntryDateTime, 120), 10)=LEFT(CONVERT(VARCHAR, @entrydate, 120), 10) order by CategoryID DESC";
                    break;
                case 1:
                    cmd.CommandText = sqlMainQuery + " AND CategoryName LIKE '%' + @SearchText + '%' order by CategoryID DESC";
                    break;
 



            }
            dad.SelectCommand = cmd;
            ds.Tables.Add("Data");
            try
            {
                UserCon.Open();
                cmd.ExecuteNonQuery();
                dad.Fill(ds.Tables["Data"]);
                return ds;
            }
            catch (Exception ex)
            {
                objutilFun.WriteErrorLog("CategoryBACL", "GetCategorySearchQueryData", ex.Message);
                return ds;
            }
            finally
            {
                UserCon.Close();
            }
        }

        private CategoryProp SetCategory(DataTable dt)
        {
            CategoryProp objCategoryProp = new CategoryProp();
            try
            {
                objCategoryProp.CategoryCode = Convert.ToInt32(dt.Rows[0]["CategoryCode"]);
                objCategoryProp.CategoryName = dt.Rows[0]["CategoryName"].ToString();
                objCategoryProp.CategoryDesc = dt.Rows[0]["CategoryDesc"].ToString();

               

            }
            catch (Exception ex)
            {
                objutilFun.WriteErrorLog("CategoryProp", "SetCategory", ex.Message);
                throw ex;
            }

            return objCategoryProp;
        }



        private List<CategoryProp> SetAllCategory(DataTable dt)
        {
           List<CategoryProp> lstCategoryProp = new List<CategoryProp>();
            CategoryProp objCategoryProp;
            try
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    objCategoryProp = new CategoryProp();
                    objCategoryProp.CategoryCode = Convert.ToInt32(dt.Rows[i]["CategoryCode"]);
                    objCategoryProp.CategoryName = dt.Rows[i]["CategoryName"].ToString();
                    objCategoryProp.CategoryDesc = dt.Rows[i]["CategoryDesc"].ToString();

                    lstCategoryProp.Add(objCategoryProp);
                }

            }
            catch (Exception ex)
            {
                objutilFun.WriteErrorLog("CategoryProp", "SetAllCategory", ex.Message);
                throw ex;
            }

            return lstCategoryProp;
        }
    }
}
