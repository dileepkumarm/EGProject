﻿using System;


namespace ShopperStock.Model
{
    public class CategoryProp
    {
        public CategoryProp()
        {
            CategoryCode = 0;
            CategoryName = string.Empty;
            CategoryDesc = string.Empty;
            SearchIndex = 0;
            SearchText = string.Empty;
            EntryDateTime = DateTime.Now;
            ModifiedDate = DateTime.Now;
            ErrorOccured = false;
        }
        public int CategoryCode { get; set; }
        public string CategoryName { get; set; }
        public string CategoryDesc { get; set; }

        public int SearchIndex { get; set; }
        public string SearchText { get; set; }
        public DateTime EntryDateTime { get; set; }
        public DateTime ModifiedDate { get; set; }
        public bool ErrorOccured { get; set; }
    }
}
