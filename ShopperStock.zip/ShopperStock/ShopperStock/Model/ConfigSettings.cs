﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace ShopperStock.Model
{
   public sealed class ConfigSettings:ConnectionManager
    {
        public override string GetLogFileConfiguration()
        {
            var LogFiles = ConfigurationManager.AppSettings["LogFiles"];
            return LogFiles;
        }

        public override ConnectionProp GetConnectionStringConfiguration()
        {
            ConnectionProp objConProp = new ConnectionProp();
            try
            {
                objConProp.MainConnection = ConfigurationManager.AppSettings["MainConnection"].ToString();
            }
            catch (Exception)
            {
                objConProp.ErrorText = "Connection String Not initialized!";
                objConProp.ErrorOccured = true;
            }
             return objConProp;
        }




    }
}
