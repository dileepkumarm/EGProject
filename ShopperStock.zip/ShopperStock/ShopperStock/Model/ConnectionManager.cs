﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopperStock.Model
{
    public abstract class ConnectionManager
    {
        public abstract string GetLogFileConfiguration();
        public abstract ConnectionProp GetConnectionStringConfiguration();

    }
}
