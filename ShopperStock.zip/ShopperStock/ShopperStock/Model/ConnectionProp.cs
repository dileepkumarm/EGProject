﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopperStock.Model
{
   public class ConnectionProp
    {
        public ConnectionProp()
        {
            MainConnection = string.Empty;
            ErrorOccured = false;
            ErrorText = string.Empty;
        }
        public string MainConnection { get; set; }

        public bool ErrorOccured { get; set; }
        public string ErrorText { get; set; }
    }
}
