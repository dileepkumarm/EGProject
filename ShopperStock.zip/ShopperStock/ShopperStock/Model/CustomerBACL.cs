﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopperStock.Model
{
  public  sealed class CustomerBACL
    {

        private readonly ConfigSettings objConfig = new ConfigSettings();
        private readonly Ihelper objutilFun = new UtilityFunction();
        private ConnectionProp objConProp = new ConnectionProp();
        public  void AddCustomer(CustomerProp objProp)
        {
            SqlCommand cmd = new SqlCommand();
            SqlConnection UserCon = new SqlConnection();
            try
            {

                objConProp = objConfig.GetConnectionStringConfiguration();
                UserCon.ConnectionString = objConProp.MainConnection;
                cmd.Connection = UserCon;
                int PLCode = GenerateCustomerCode();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "Insert Into  S_Customer (PLCode,PLName,PLEmail,PLAddress1,PLAddress2,PLCity,PLState,PLPIN,PLPhone,PLEntryDate)  values(@PLCode,@PLName,@PLEmail,@PLAddress1,@PLAddress2,@PLCity,@PLState,@PLPIN,@PLPhone,@PLEntryDate)";
                cmd.Parameters.Add("@PLCode", SqlDbType.Int).Value = PLCode;
                cmd.Parameters.Add("@PLName", SqlDbType.VarChar).Value = objProp.PLName;
                cmd.Parameters.Add("@PLEmail", SqlDbType.VarChar).Value = objProp.PLEmail;
                cmd.Parameters.Add("@PLAddress1", SqlDbType.VarChar).Value = objProp.PLAddress1;
                cmd.Parameters.Add("@PLAddress2", SqlDbType.VarChar).Value = objProp.PLAddress2;
                cmd.Parameters.Add("@PLCity", SqlDbType.VarChar).Value = objProp.PLCity;
                cmd.Parameters.Add("@PLState", SqlDbType.VarChar).Value = objProp.PLState;
                cmd.Parameters.Add("@PLPIN", SqlDbType.VarChar).Value = objProp.PLPIN;
                cmd.Parameters.Add("@PLPhone", SqlDbType.VarChar).Value = objProp.PLPhone;
                cmd.Parameters.Add("@PLEntryDate", SqlDbType.SmallDateTime).Value = DateTime.Now;

                try
                {
                    UserCon.Open();
                    cmd.ExecuteNonQuery();
                    UserCon.Close();

                }
                catch (Exception ex)
                {
                    objProp.ErrorOccured = true;
                    objutilFun.WriteErrorLog("CustomerBACL", " Inner AddCustomer", ex.Message);
                    throw ex;
                }
                finally
                {
                    UserCon.Close();
                }
            }
            catch (Exception ex)
            {
                objProp.ErrorOccured = true;
                objutilFun.WriteErrorLog("CustomerBACL", "Outer AddCustomer", ex.Message);
            }
        }

        public void EditCustomer(CustomerProp objProp)
        {
            SqlCommand cmd = new SqlCommand();
            SqlConnection UserCon = new SqlConnection();
            try
            {

                objConProp = objConfig.GetConnectionStringConfiguration();
                UserCon.ConnectionString = objConProp.MainConnection;
                cmd.Connection = UserCon;

                cmd.CommandText = "Update  S_Customer set PLName=@PLName,PLEmail=@PLEmail,PLAddress1=@PLAddress1,PLAddress2=@PLAddress2,PLCity=@PLCity,PLState=@PLState,PLPIN=@PLPIN,PLPhone=@PLPhone,PLModifiedDate = @PLModifiedDate where PLCode= @PLCode; ";
                cmd.Parameters.Add("@PLCode", SqlDbType.Int).Value = objProp.PLCode; 
                cmd.Parameters.Add("@PLName", SqlDbType.VarChar).Value = objProp.PLName;
                cmd.Parameters.Add("@PLAddress1", SqlDbType.VarChar).Value = objProp.PLAddress1;
                cmd.Parameters.Add("@PLAddress2", SqlDbType.VarChar).Value = objProp.PLAddress2;
                cmd.Parameters.Add("@PLEmail", SqlDbType.VarChar).Value = objProp.PLEmail;
                cmd.Parameters.Add("@PLCity", SqlDbType.VarChar).Value = objProp.PLCity;
                cmd.Parameters.Add("@PLState", SqlDbType.VarChar).Value = objProp.PLState;
                cmd.Parameters.Add("@PLPIN", SqlDbType.VarChar).Value = objProp.PLPIN;
                cmd.Parameters.Add("@PLPhone", SqlDbType.VarChar).Value = objProp.PLPhone;
                cmd.Parameters.Add("@PLModifiedDate", SqlDbType.SmallDateTime).Value = DateTime.Now;

                try
                {
                    UserCon.Open();
                    cmd.ExecuteNonQuery();
                    UserCon.Close();

                }
                catch (Exception ex)
                {
                    objProp.ErrorOccured = true;
                    objutilFun.WriteErrorLog("CustomerBACL", "Inner method EditCustomer", ex.Message);
                }
                finally
                {
                    UserCon.Close();
                }
            }
            catch (Exception ex)
            {
                objProp.ErrorOccured = true;
                objutilFun.WriteErrorLog("CustomerBACL", "Outer method EditCustomer", ex.Message);
                throw ex;
            }
        }
        public CustomerProp GetCustomer(CustomerProp objHProp)
        {
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter dad = new SqlDataAdapter();
            DataTable ds = new DataTable();
            SqlConnection UserCon = new SqlConnection();
            CustomerProp objCustomerProp = new CustomerProp();

            objConProp = objConfig.GetConnectionStringConfiguration();
            UserCon.ConnectionString = objConProp.MainConnection;
            cmd.Connection = UserCon;

            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select PLCode,PLName,PLEmail,PLAddress1,PLAddress2,PLCity,PLState,PLPIN,PLPhone from S_Customer where PLCode= @PLCode";
            cmd.Parameters.Add("@PLCode", SqlDbType.Int).Value = objHProp.PLCode;
            dad.SelectCommand = cmd;

            try
            {
                UserCon.Open();
                cmd.ExecuteNonQuery();
                UserCon.Close();
                dad.Fill(ds);
                if (ds.Rows.Count > 0)
                {
                    objCustomerProp = SetCustomer(ds);
                }
            }
            catch (Exception ex)
            {
                objutilFun.WriteErrorLog("CustomerBACL", "GetCustomer", ex.Message);
                objCustomerProp.ErrorOccured = true;
            }
            finally
            {
                UserCon.Close();
            }

            return objCustomerProp;
        }


        public void DeleteCustomer(CustomerProp objProp)
        {
            SqlCommand cmd = new SqlCommand();
            SqlConnection UserCon = new SqlConnection();
            try
            {

                objConProp = objConfig.GetConnectionStringConfiguration();
                UserCon.ConnectionString = objConProp.MainConnection;
                cmd.Connection = UserCon;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "Delete from S_Customer Where PLCode= @PLCode";
                cmd.Parameters.Add("@PLCode", SqlDbType.Int).Value = objProp.PLCode;
                try
                {
                    UserCon.Open();
                    cmd.ExecuteNonQuery();
                    UserCon.Close();

                }
                catch (Exception ex)
                {
                    objProp.ErrorOccured = true;
                    objutilFun.WriteErrorLog("CustomerBACL", " DeleteCustomer", ex.Message);
                    throw ex;
                }
                finally
                {
                    UserCon.Close();
                }
            }
            catch (Exception ex)
            {
                objProp.ErrorOccured = true;
                objutilFun.WriteErrorLog("CustomerBACL", "DeleteCustomer", ex.Message);
            }
        }


        public DataTable GetAllCustomer(CustomerProp objHProp)
        {
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter dad = new SqlDataAdapter();
            DataTable ds = new DataTable();
            SqlConnection UserCon = new SqlConnection();

            objConProp = objConfig.GetConnectionStringConfiguration();
            UserCon.ConnectionString = objConProp.MainConnection;
            cmd.Connection = UserCon;

            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select PLCode,PLName from S_Customer";
            dad.SelectCommand = cmd;

            try
            {
                UserCon.Open();
                cmd.ExecuteNonQuery();
                UserCon.Close();
                dad.Fill(ds);
            }
            catch (Exception ex)
            {
                objutilFun.WriteErrorLog("CustomerBACL", "GetCustomer", ex.Message);
                objHProp.ErrorOccured = true;
            }
            finally
            {
                UserCon.Close();
            }

            return ds;
        }


        private int GenerateCustomerCode()
        {
            int CustomerCode;
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter dad = new SqlDataAdapter();
            DataTable ds = new DataTable();
            SqlConnection UserCon = new SqlConnection();

            objConProp = objConfig.GetConnectionStringConfiguration();
            UserCon.ConnectionString = objConProp.MainConnection;
            cmd.Connection = UserCon;

            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select  Isnull(max(PLCode),0) as PLCode  from S_Customer";
            dad.SelectCommand = cmd;

            try
            {
                UserCon.Open();
                cmd.ExecuteNonQuery();
                UserCon.Close();
                dad.Fill(ds);
                if (ds.Rows.Count > 0)
                {
                    CustomerCode = Convert.ToInt32(ds.Rows[0]["PLCode"]) + 1;
                }
                else
                {
                    CustomerCode = 1;
                }
            }
            catch (Exception ex)
            {
                objutilFun.WriteErrorLog("CustomerBACL", "GenerateCustomerCode", ex.Message);
                throw ex;
            }
            finally
            {
                UserCon.Close();
            }

            return CustomerCode;
        }
        public DataSet GetCustomerSearchQueryData(CustomerProp objProp)
        {
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter dad = new SqlDataAdapter();
            DataSet ds = new DataSet();
            SqlConnection UserCon = new SqlConnection();

            objConProp = objConfig.GetConnectionStringConfiguration();
            UserCon.ConnectionString = objConProp.MainConnection;
            cmd.Connection = UserCon;

            var datetime = DateTime.Now;
            var entrydate = datetime.Date;

            cmd.CommandType = CommandType.Text;
            cmd.Parameters.Add("@SearchText", SqlDbType.VarChar, 50).Value = objProp.SearchText;
            cmd.Parameters.Add("@entrydate", SqlDbType.SmallDateTime, 50).Value = entrydate;

            string sqlMainQuery = "SELECT  PLCode,PLName,PLAddress1,PLAddress2,PLCity,PLPIN,PLPhone,PLEmail from S_Customer  where 1=1 ";
            switch (objProp.SearchIndex)
            {
                case 0:
                    cmd.CommandText = sqlMainQuery + " AND LEFT(CONVERT(VARCHAR, PLEntryDate, 120), 10)=LEFT(CONVERT(VARCHAR, @entrydate, 120), 10) order by PLCode DESC";
                    break;
                case 1:
                    cmd.CommandText = sqlMainQuery + " AND PLName LIKE '%' + @SearchText + '%' order by PLCode DESC";
                    break;
            }
            dad.SelectCommand = cmd;
            ds.Tables.Add("Data");
            try
            {
                UserCon.Open();
                cmd.ExecuteNonQuery();
                dad.Fill(ds.Tables["Data"]);
                return ds;
            }
            catch (Exception ex)
            {
                objutilFun.WriteErrorLog("CustomerBACL", "GetCustomerSearchQueryData", ex.Message);
                return ds;
            }
            finally
            {
                UserCon.Close();
            }
        }

        private CustomerProp SetCustomer(DataTable dt)
        {
            CustomerProp objPLProp = new CustomerProp();
            try
            {
                objPLProp.PLCode = Convert.ToInt32(dt.Rows[0]["PLCode"]);
                objPLProp.PLName = dt.Rows[0]["PLName"].ToString();
                objPLProp.PLEmail = dt.Rows[0]["PLEmail"].ToString();

                objPLProp.PLAddress1 = dt.Rows[0]["PLAddress1"].ToString();
                objPLProp.PLAddress2 = dt.Rows[0]["PLAddress2"].ToString();
                objPLProp.PLCity = dt.Rows[0]["PLCity"].ToString();
                objPLProp.PLState = dt.Rows[0]["PLState"].ToString();
                objPLProp.PLPIN = Convert.ToInt32(dt.Rows[0]["PLPIN"]); 
                objPLProp.PLPhone = dt.Rows[0]["PLPhone"].ToString();

            }
            catch (Exception ex)
            {
                objutilFun.WriteErrorLog("CustomerProp", "SetCustomer", ex.Message);
                throw ex;
            }

            return objPLProp;
        }


    }
}
