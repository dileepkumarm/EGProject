﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopperStock.Model
{
    public class CustomerProp
    {
        public CustomerProp()
        {
            PLCode = 0;
            PLName =string.Empty;
            PLAddress1 =string.Empty;
            PLAddress2 =string.Empty;
            PLCity =string.Empty;
            PLState =string.Empty;
            PLPIN = 0;
            PLPhone =string.Empty;
            PLEmail = string.Empty;
            EntryDateTime =DateTime.Now;
            ModifiedDate = DateTime.Now;
            ErrorOccured = false;
            SearchIndex = 0;
            SearchText = string.Empty;
        }


        public int PLCode { get; set; }
	    public string PLName { get; set; }
        public string PLAddress1 { get; set; }
        public string PLAddress2 { get; set; }
        public string PLCity { get; set; }
        public string PLState { get; set; }
        public int PLPIN { get; set; }
        public string PLPhone { get; set; }
        public string PLEmail{ get; set; }
        public DateTime EntryDateTime { get; set; }
        public DateTime ModifiedDate { get; set; }
        public bool ErrorOccured { get; set; }
        public int SearchIndex { get; set; }
        public string SearchText { get; set; }
    }
}
