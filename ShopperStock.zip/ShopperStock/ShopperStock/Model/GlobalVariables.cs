﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static ShopperStock.Model.UtilEnum;

namespace ShopperStock.Model
{
    public static class GlobalVariables
    {
        public static int gblRecordID;
        public static OperationType gblOperType;
        public static LookUpType LookUpType;
        public static String LookUpName = "";
        public static String LookUpCode = "";
        public static String LookUpPartyName = "";
        public static String LookUpPartyCode = "";

    }


}
