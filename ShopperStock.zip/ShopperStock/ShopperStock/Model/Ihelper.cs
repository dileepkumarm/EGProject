﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopperStock.Model
{
    interface Ihelper
    {
        void WriteErrorLog(string SourceClass, string SourceMethod, string errorMessage);
        string GetEnumDescription(Enum value);
    }
}
