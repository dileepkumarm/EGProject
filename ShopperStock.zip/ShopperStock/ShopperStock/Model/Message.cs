﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopperStock.Model
{
  public  class MessageBL
    {
        private string strMessage = string.Empty;
        public string GetDisplayMessage(int MainMsgNo, int SubMsgNo)
        {
            switch (MainMsgNo)
            {
                case 0:
                    switch (SubMsgNo)
                    {
   
                        case 0:
                            strMessage = "Error Occured during current operation." + Environment.NewLine + " Please check Error Log file for more Information";
                            break;
                          case 1:
                            strMessage = "Data Restored Sucessfully";
                            break;
                            break;
                        case 2:
                            strMessage = "Invalid Email ID";
                            break;
                        case 3:
                            strMessage = "Please enter the details";
                            break;

                        case 4:
                            strMessage = "Data Saved Sucessfully";
                            break;
                        case 5:
                            strMessage = "Data Deleted Sucessfully";
                            break;
                        case 6:
                            strMessage = "Order Placed successfully!!";
                            break;
                        case 7:
                            strMessage = "Would you like to generate Invoice?";
                            break;
                        case 8:
                            strMessage = "Invoice generated!!";
                            break;



                    }
                    break;
            }
            return strMessage;
        }

    }
}
