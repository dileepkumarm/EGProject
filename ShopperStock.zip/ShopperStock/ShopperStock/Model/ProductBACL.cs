﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopperStock.Model
{
    public sealed class ProductBACL
    {
        private readonly ConfigSettings objConfig = new ConfigSettings();
        private readonly Ihelper objutilFun = new UtilityFunction();
        private  ConnectionProp objConProp = new ConnectionProp();
        public void AddProduct(ProductProp objProp)
        {
            SqlCommand cmd = new SqlCommand();
 
            SqlConnection UserCon = new SqlConnection();
            try
            {

                objConProp = objConfig.GetConnectionStringConfiguration();
                UserCon.ConnectionString = objConProp.MainConnection;
                cmd.Connection = UserCon;
                int ProductCode = GenerateProductCode();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "Insert Into  S_Product (ProductCode,ProductName, ProductCategoryCode,ProductDesc, ProductSalesRate, ProductQty, ProductEntryDate)  values(@ProductCode,@ProductName, @ProductCategoryCode,@ProductDesc,@ProductSalesRate, @ProductQty,@ProductEntryDate)";
                cmd.Parameters.Add("@ProductCode", SqlDbType.Int).Value = ProductCode;
                cmd.Parameters.Add("@ProductName", SqlDbType.VarChar).Value = objProp.ProductName;
                cmd.Parameters.Add("@ProductDesc", SqlDbType.VarChar).Value = objProp.ProductDesc;
                cmd.Parameters.Add("@ProductCategoryCode", SqlDbType.VarChar).Value = objProp.ProductCategoryCode;
                cmd.Parameters.Add("@ProductSalesRate", SqlDbType.Decimal).Value = objProp.ProductSalesRate;
                cmd.Parameters.Add("@ProductQty", SqlDbType.Int).Value = objProp.ProductQty;
                      cmd.Parameters.Add("@ProductEntryDate", SqlDbType.SmallDateTime).Value = DateTime.Now;

                try
                {
                    UserCon.Open();
                    cmd.ExecuteNonQuery();
                    UserCon.Close();

                }
                catch (Exception ex)
                {
                    objProp.ErrorOccured = true;
                    objutilFun.WriteErrorLog("ProductBACL", " Inner AddProduct", ex.Message);
                    throw ex;
                }
                finally
                {
                    UserCon.Close();
                }
            }
            catch (Exception ex)
            {
                objProp.ErrorOccured = true;
                objutilFun.WriteErrorLog("ProductBACL", "Outer AddProduct", ex.Message);
            }
        }

        public void EditProduct(ProductProp objProp)
        {
            SqlCommand cmd = new SqlCommand();
            SqlConnection UserCon = new SqlConnection();
            try
            {

                objConProp = objConfig.GetConnectionStringConfiguration();
                UserCon.ConnectionString = objConProp.MainConnection;
                cmd.Connection = UserCon;

                cmd.CommandText = "Update  S_Product set ProductName=@ProductName,ProductDesc=@ProductDesc,ProductCategoryCode= @ProductCategoryCode, ProductSalesRate=@ProductSalesRate,ProductQty= @ProductQty,ProductModifiedDate=@ProductModifiedDate where ProductCode= @ProductCode; ";
                cmd.Parameters.Add("@ProductCode", SqlDbType.Int).Value = objProp.ProductCode; 
                cmd.Parameters.Add("@ProductName", SqlDbType.VarChar).Value = objProp.ProductName;
                cmd.Parameters.Add("@ProductDesc", SqlDbType.VarChar).Value = objProp.ProductDesc;
                cmd.Parameters.Add("@ProductCategoryCode", SqlDbType.VarChar).Value = objProp.ProductCategoryCode;
                cmd.Parameters.Add("@ProductSalesRate", SqlDbType.Decimal).Value = objProp.ProductSalesRate;
                cmd.Parameters.Add("@ProductQty", SqlDbType.Int).Value = objProp.ProductQty;
                cmd.Parameters.Add("@ProductModifiedDate", SqlDbType.SmallDateTime).Value = DateTime.Now;

                try
                {
                    UserCon.Open();
                    cmd.ExecuteNonQuery();
                    UserCon.Close();

                }
                catch (Exception ex)
                {
                    objProp.ErrorOccured = true;
                    objutilFun.WriteErrorLog("ProductBACL", "Inner method EditProduct", ex.Message);
                }
                finally
                {
                    UserCon.Close();
                }
            }
            catch (Exception ex)
            {
                objProp.ErrorOccured = true;
                objutilFun.WriteErrorLog("ProductBACL", "Outer method EditProduct", ex.Message);
                throw ex;
            }
        }
        public ProductProp GetProduct(ProductProp objHProp)
        {
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter dad = new SqlDataAdapter();
            DataTable ds = new DataTable();
            SqlConnection UserCon = new SqlConnection();
            ProductProp objProductProp = new ProductProp();

            objConProp = objConfig.GetConnectionStringConfiguration();
            UserCon.ConnectionString = objConProp.MainConnection;
            cmd.Connection = UserCon;

            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select ProductCode,ProductName,ProductDesc, ProductCategoryCode,CategoryName as 'ProductCategoryName', ProductSalesRate, ProductQty from S_Product s Inner join S_CategoryMaster h on s.ProductCategoryCode = h.CategoryCode where ProductCode = @ProductCode";
            cmd.Parameters.Add("@ProductCode", SqlDbType.Int).Value = objHProp.ProductCode;
            dad.SelectCommand = cmd;

            try
            {
                UserCon.Open();
                cmd.ExecuteNonQuery();
                UserCon.Close();
                dad.Fill(ds);
                if (ds.Rows.Count > 0)
                {
                    objProductProp = SetProduct(ds);
                }
            }
            catch (Exception ex)
            {
                objutilFun.WriteErrorLog("ProductBACL", "GetProduct", ex.Message);
                objProductProp.ErrorOccured = true;
            }
            finally
            {
                UserCon.Close();
            }

            return objProductProp;
        }
        public void DeleteProduct(ProductProp objProp)
        {
            SqlCommand cmd = new SqlCommand();
            SqlConnection UserCon = new SqlConnection();
            try
            {

                objConProp = objConfig.GetConnectionStringConfiguration();
                UserCon.ConnectionString = objConProp.MainConnection;
                cmd.Connection = UserCon;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "Delete from S_Product Where ProductCode= @ProductCode";
                cmd.Parameters.Add("@ProductCode", SqlDbType.Int).Value = objProp.ProductCode;
                try
                {
                    UserCon.Open();
                    cmd.ExecuteNonQuery();
                    UserCon.Close();

                }
                catch (Exception ex)
                {
                    objProp.ErrorOccured = true;
                    objutilFun.WriteErrorLog("ProductBACL", " DeleteCustomer", ex.Message);
                    throw ex;
                }
                finally
                {
                    UserCon.Close();
                }
            }
            catch (Exception ex)
            {
                objProp.ErrorOccured = true;
                objutilFun.WriteErrorLog("ProductBACL", "DeleteCustomer", ex.Message);
            }
        }
        public DataTable GetAllProduct(ProductProp objHProp)
        {
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter dad = new SqlDataAdapter();
            DataTable ds = new DataTable();
            SqlConnection UserCon = new SqlConnection();
    

            objConProp = objConfig.GetConnectionStringConfiguration();
            UserCon.ConnectionString = objConProp.MainConnection;
            cmd.Connection = UserCon;

            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select ProductCode,ProductName from S_Product s with (NOLOCK)";
            dad.SelectCommand = cmd;

            try
            {
                UserCon.Open();
                cmd.ExecuteNonQuery();
                UserCon.Close();
                dad.Fill(ds);

            }
            catch (Exception ex)
            {
                objutilFun.WriteErrorLog("ProductBACL", "GetAllProduct", ex.Message);
                objHProp.ErrorOccured = true;
            }
            finally
            {
                UserCon.Close();
            }

            return ds;
        }
        public DataTable GetCategory(ProductProp objPProp)
        {
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter dad = new SqlDataAdapter();
            DataTable ds = new DataTable();
            SqlConnection UserCon = new SqlConnection();

            objConProp = objConfig.GetConnectionStringConfiguration();
            UserCon.ConnectionString = objConProp.MainConnection;
            cmd.Connection = UserCon;

            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select CategoryCode,CategoryName from S_CategoryMaster";
            dad.SelectCommand = cmd;

            try
            {
                UserCon.Open();
                cmd.ExecuteNonQuery();
                UserCon.Close();
                dad.Fill(ds);
            }
            catch (Exception ex)
            {
                objutilFun.WriteErrorLog("ProductBACL", "GetCategory", ex.Message);
                objPProp.ErrorOccured = true;
            }
            finally
            {
                UserCon.Close();
            }

            return ds;
        }
        private int GenerateProductCode()
        {
            int ProductCode;
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter dad = new SqlDataAdapter();
            DataTable ds = new DataTable();
            SqlConnection UserCon = new SqlConnection();

            objConProp = objConfig.GetConnectionStringConfiguration();
            UserCon.ConnectionString = objConProp.MainConnection;
            cmd.Connection = UserCon;

            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select  Isnull(max(ProductCode),0) as ProductCode  from S_Product";
            dad.SelectCommand = cmd;

            try
            {
                UserCon.Open();
                cmd.ExecuteNonQuery();
                UserCon.Close();
                dad.Fill(ds);
                if (ds.Rows.Count > 0)
                {
                    ProductCode = Convert.ToInt32(ds.Rows[0]["ProductCode"]) + 1;
                }
                else
                {
                    ProductCode = 1;
                }
            }
            catch (Exception ex)
            {
                objutilFun.WriteErrorLog("ProductBACL", "GenerateProductCode", ex.Message);
                throw ex;
            }
            finally
            {
                UserCon.Close();
            }

            return ProductCode;
        }
        public DataSet GetProductSearchQueryData(ProductProp objProp)
        {
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter dad = new SqlDataAdapter();
            DataSet ds = new DataSet();
            SqlConnection UserCon = new SqlConnection();

            objConProp = objConfig.GetConnectionStringConfiguration();
            UserCon.ConnectionString = objConProp.MainConnection;
            cmd.Connection = UserCon;

            var datetime = DateTime.Now;
            var entrydate = datetime.Date;

            cmd.CommandType = CommandType.Text;
            cmd.Parameters.Add("@SearchText", SqlDbType.VarChar, 50).Value = objProp.SearchText;
            cmd.Parameters.Add("@entrydate", SqlDbType.SmallDateTime, 50).Value = entrydate;

            string sqlMainQuery = "	SELECT  ProductCode,ProductName, CategoryName as 'ProductCategoryName',  ProductSalesRate,ProductQty  from S_Product S Inner Join S_CategoryMaster H on  S.ProductCategoryCode = H.CategoryCode  where 1 = 1";
            switch (objProp.SearchIndex)
            {
                case 0:
                    cmd.CommandText = sqlMainQuery + " AND LEFT(CONVERT(VARCHAR, ProductEntryDate, 120), 10)=LEFT(CONVERT(VARCHAR, @entrydate, 120), 10) order by ProductCode DESC";
                    break;
                case 1:
                    cmd.CommandText = sqlMainQuery + " AND ProductName LIKE '%' + @SearchText + '%' order by ProductCode DESC";
                    break;

            }
            dad.SelectCommand = cmd;
            ds.Tables.Add("Data");
            try
            {
                UserCon.Open();
                cmd.ExecuteNonQuery();
                dad.Fill(ds.Tables["Data"]);
                return ds;
            }
            catch (Exception ex)
            {
                objutilFun.WriteErrorLog("ProductBACL", "GetProductSearchQueryData", ex.Message);
                return ds;
            }
            finally
            {
                UserCon.Close();
            }
        }

        private ProductProp SetProduct(DataTable dt)
        {
            ProductProp objProductProp = new ProductProp();
            try
            {

                objProductProp.ProductCode = Convert.ToInt32(dt.Rows[0]["ProductCode"]);
                objProductProp.ProductName = dt.Rows[0]["ProductName"].ToString();
                objProductProp.ProductDesc = dt.Rows[0]["ProductDesc"].ToString();
                objProductProp.ProductCategoryCode = dt.Rows[0]["ProductCategoryCode"].ToString();
                objProductProp.ProductCategoryName = dt.Rows[0]["ProductCategoryName"].ToString();
                objProductProp.ProductSalesRate = Convert.ToDecimal(dt.Rows[0]["ProductSalesRate"].ToString());
                objProductProp.ProductQty = Convert.ToInt32(dt.Rows[0]["ProductQty"].ToString());
                objProductProp.ProductDesc = dt.Rows[0]["ProductDesc"].ToString();

            }
            catch (Exception ex)
            {
                objutilFun.WriteErrorLog("ProductProp", "SetProduct", ex.Message);
                throw ex;
            }

            return objProductProp;
        }


    }
}
