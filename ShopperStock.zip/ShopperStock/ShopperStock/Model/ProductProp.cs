﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopperStock.Model
{
  public  class ProductProp
    {
        public ProductProp()
        {
        ProductCode =0;
        ProductName =string.Empty;
        ProductDesc =string.Empty;
        ProductCategoryCode =string.Empty;
        ProductCategoryName = string.Empty;
        ProductSalesRate = 0;
        ProductQty = 0;
        SearchIndex = 0;
        SearchText =string.Empty;
        ProductEntryDate = DateTime.Now;
        ProductModifiedDate = DateTime.Now;
        ErrorOccured = false;
    }
        public int  ProductCode { get; set; }
        public string ProductName { get; set; }
        public string ProductDesc { get; set; }
        public string ProductCategoryCode { get; set; }
        public string ProductCategoryName { get; set; }
        public decimal ProductSalesRate { get; set; }
        public int ProductQty { get; set; }
        public int SearchIndex { get; set; }
        public string SearchText { get; set; }
        public DateTime ProductEntryDate { get; set; }
        public DateTime ProductModifiedDate { get; set; } 
        public bool ErrorOccured { get; set; }
    }
}

