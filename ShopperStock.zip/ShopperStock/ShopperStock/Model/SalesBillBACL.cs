﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopperStock.Model
{
    public sealed class SalesBillBACL
    {
        private readonly ConfigSettings objConfig = new ConfigSettings();
        private readonly UtilityFunction objutilFun = new UtilityFunction();
        private ConnectionProp objConProp = new ConnectionProp();
        public void AddSales(SalesBillProp objProp)
        {
            SqlCommand cmd = new SqlCommand();
            SqlConnection UserCon = new SqlConnection();
            SqlTransaction sqlTran = null;

            cmd.CommandType = CommandType.Text;
            objConProp = objConfig.GetConnectionStringConfiguration();
            UserCon.ConnectionString = objConProp.MainConnection;
            cmd.Connection = UserCon;
            cmd.CommandType = CommandType.Text;
            try
            {
                cmd = new SqlCommand();
                cmd.Connection = UserCon;
                cmd.Parameters.Clear();
                UserCon.Open();
                sqlTran = UserCon.BeginTransaction();
                cmd.Transaction = sqlTran;
    
                cmd.CommandText = "Insert Into  S_SalesBillMast" +
                    " (SBMastPartyID,SBMastPartyName,SBMastProductCode,SBMastProductName,SBMastQty,SBMastEntryDate,SBMastInvoiceAmt,SBMastSalesRate ,SBMastDisc,SBMastTax)  " +
                    "values(@SBMastPartyID,@SBMastPartyName,@SBMastProductCode,@SBMastProductName,@SBMastQty,@SBMastEntryDate,@SBMastInvoiceAmt,@SBMastSalesRate ,@SBMastDisc,@SBMastTax)";
                cmd.Parameters.Add("@SBMastPartyID", SqlDbType.VarChar).Value = objProp.SBMastPartyID;
                cmd.Parameters.Add("@SBMastPartyName", SqlDbType.VarChar).Value = objProp.SBMastPartyName;
                cmd.Parameters.Add("@SBMastProductCode", SqlDbType.VarChar).Value = objProp.SBMastProductCode;
                cmd.Parameters.Add("@SBMastProductName", SqlDbType.VarChar).Value = objProp.SBMastProductName;
                cmd.Parameters.Add("@SBMastQty", SqlDbType.Int).Value = objProp.SBMastQty;
                cmd.Parameters.Add("@SBMastSalesRate", SqlDbType.Decimal).Value = objProp.SBMastSalesRate;
                cmd.Parameters.Add("@SBMastTax", SqlDbType.Decimal).Value = objProp.SBMastTax;
                cmd.Parameters.Add("@SBMastDisc", SqlDbType.Decimal).Value = objProp.SBMastDisc;
                cmd.Parameters.Add("@SBMastInvoiceAmt", SqlDbType.Decimal).Value = objProp.SBMastInvoiceAmt;
                 cmd.Parameters.Add("@SBMastEntryDate", SqlDbType.SmallDateTime).Value = DateTime.Now;

                cmd.ExecuteNonQuery();

                sqlTran.Commit();
            }
            catch (Exception ex)
            {
                objProp.ErrorOccured = true;
                objutilFun.WriteErrorLog("SalesBACL", "Inner method EditSales", ex.Message);
                sqlTran.Rollback();
            }
            finally
            {
                UserCon.Close();
            }


        }

    }
}
