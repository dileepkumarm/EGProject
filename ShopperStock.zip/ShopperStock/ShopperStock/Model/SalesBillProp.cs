﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopperStock.Model
{
    public class SalesBillProp
    {

        public SalesBillProp()
        {
            SBMastCode = 0;
            SBMastProductCode = 0;
            SBMastPartyID = string.Empty;
            SBMastProductName = string.Empty;
            SBMastPartyName = string.Empty;
            SBMastEntryDate = DateTime.Now;
            SBMastModifiedDate = DateTime.Now;
            SBMastTax = 0;
            SBMastDisc = 0;
            SBMastInvoiceAmt = 0;
            SBMastSalesRate = 0;
            SBMastQty = 0;
            ErrorOccured = false;
            SearchIndex = 0;
            SearchText = string.Empty;
            ErrorOccured = false;

        }


        public int SBMastCode { get; set; }
        public string SBMastPartyID { get; set; }
        public string SBMastPartyName { get; set; }
        public int SBMastProductCode { get; set; }
        public string SBMastProductName { get; set; }
        public int SBMastQty{ get; set; }
        public decimal SBMastSalesRate { get; set; }
        public decimal SBMastDisc { get; set; }
        public decimal SBMastTax { get; set; }
        public DateTime SBMastEntryDate { get; set; }
        public DateTime SBMastModifiedDate { get; set; }
        public decimal SBMastInvoiceAmt { get; set; }

        public int SearchIndex { get; set; }

        public string SearchText { get; set; }

        public bool ErrorOccured { get; set; }

    }
}
