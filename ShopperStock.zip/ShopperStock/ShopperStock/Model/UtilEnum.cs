﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopperStock.Model
{
   public class UtilEnum
    {
        public enum OperationType
        {
            None = 0,
            Add = 1,
            Edit = 2,
            Delete = 3,
            View = 4,
        }





        public enum LookUpType
        {
            Category = 0,
            Product = 1,
            Party = 2,

        }

        public enum CategorySearch
        {
            [Description("Todays Entry")]
            TodaysEntry,
            [Description("Category")]
            CategoryName,
        }

        public enum CustomerSearch
        {
            [Description("Todays Entry")]
            TodaysEntry,
            [Description("Customer Name")]
            CustomerName

        }

        }
        public enum ProductSearch
        {
            [Description("Todays Entry")]
            TodaysEntry,
            [Description("Product Name")]
            ProductName
        }



}
