﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace ShopperStock.Model
{
    public class UtilityFunction:Ihelper
    {
        ConfigSettings objconfig = new ConfigSettings();

        public void WriteErrorLog(string SourceClass, string SourceMethod, string errorMessage)
        {

            string FileName = "\\Shopper Stock Log.txt";
            try
            {
                string LogDirectory = objconfig.GetLogFileConfiguration();
                if (!new DirectoryInfo(LogDirectory).Exists)
                {
                    Directory.CreateDirectory(LogDirectory);
                }
                if (!File.Exists(LogDirectory + FileName))
                {
                    File.Create(LogDirectory + FileName).Close();
                }
                StreamWriter sw = File.AppendText(LogDirectory + FileName);
                using (sw)
                {
                    sw.WriteLine("Log Entry : {0}", DateTime.Now.ToString());
                    string err2 = "Error in Class: " + SourceClass + ", Method: " + SourceMethod;
                    sw.WriteLine(err2);
                    err2 = "Error Message:" + errorMessage;
                    sw.WriteLine(err2);
                    sw.WriteLine("__________________________");
                    sw.Flush();
                    sw.Close();
                }
            }
            catch (Exception)
            {
                
            }
        }
        public string GetEnumDescription(Enum value)
        {
            DescriptionAttribute[] attributes = (DescriptionAttribute[])value.GetType().GetField(value.ToString()).GetCustomAttributes(typeof(DescriptionAttribute), inherit: false);
            if (attributes != null && attributes.Length != 0)
            {
                return attributes[0].Description;
            }
            return value.ToString();
        }

 
    }
}
