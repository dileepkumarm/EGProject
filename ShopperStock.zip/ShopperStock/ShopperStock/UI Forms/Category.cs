﻿using ShopperStock.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static ShopperStock.Model.UtilEnum;

namespace ShopperStock.UI_Forms
{
    public partial class Category : Form
    {
        public Category()
        {
            InitializeComponent();
        }

        private readonly MessageBL objMsg = new MessageBL();
        private readonly CategoryBACL objBACL = new CategoryBACL();
        private readonly CategoryProp objProp = new CategoryProp();
        private OperationType OperType;
        private void CategoryMaster_Load(object sender, EventArgs e)
        {
            OperType = GlobalVariables.gblOperType;
            objProp.CategoryCode = GlobalVariables.gblRecordID;

            if (OperType == OperationType.Add)    //Modifications
            {
                VisibleSpecificControls(false);
                EnableControls(true);
                VisibleButtons(true);
            }
            if (OperType == OperationType.View)    //Modifications
            {
                DisplayFromDB();
                EnableControls(false);
                VisibleSpecificControls(true);
                VisibleButtons(false);
            }
            txtCategory.Select();
        }
        private void btnNext_Click(object sender, EventArgs e)
        {
            objProp.CategoryCode = Convert.ToInt32(lblCategoryCode.Text) + 1;
            if (OperType == OperationType.View)    //Modifications
            {
                DisplayFromDB();
                EnableControls(false);
                VisibleSpecificControls(true);
                VisibleButtons(false);
            }
            if (OperType == OperationType.Edit)    //Modifications
            {
                DisplayFromDB();
                EnableControls(true);
                VisibleSpecificControls(true);
                VisibleButtons(true);
                txtCategory.Select();
            }

        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            objProp.CategoryCode = Convert.ToInt32(lblCategoryCode.Text) - 1;
            if (OperType == OperationType.View)    //Modifications
            {
                DisplayFromDB();
                EnableControls(false);
                VisibleSpecificControls(true);
                VisibleButtons(false);
            }
            if (OperType == OperationType.Edit)    //Modifications
            {
                DisplayFromDB();
                EnableControls(true);
                VisibleSpecificControls(true);
                VisibleButtons(true);
                txtCategory.Select();
            }
        }
        private void btnEdit_Click(object sender, EventArgs e)
        {
            OperType = OperationType.Edit;
            EnableControls(true);
            VisibleSpecificControls(true);
            VisibleButtons(true);
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ValidateAll() == false)
                return;

            SaveData();
            if (objProp.ErrorOccured == true)
            {
                MessageBox.Show(objMsg.GetDisplayMessage(0, 0), Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                MessageBox.Show(objMsg.GetDisplayMessage(0, 4), Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void txtCategory_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtDesc.Select();
            }
        }

        private void txtDesc_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnSave.Select();
            }
        }








        protected override bool ProcessDialogKey(Keys keyData)
        {
            if (Form.ModifierKeys == Keys.None && keyData == Keys.Escape)
            {
                this.Close();
                return true;
            }
            return base.ProcessDialogKey(keyData);
        }
        private void EnableControls(Boolean val)
        {

            txtCategory.Enabled = val;
            txtDesc.Enabled = val;

        }

        private void DisplayFromDB()
        {

           CategoryProp objNewProp= objBACL.GetCategory(objProp);
            if (objNewProp.ErrorOccured == true)
            {
                MessageBox.Show(objMsg.GetDisplayMessage(0, 0), Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            MapToScreenFields(objNewProp);
        }
        private void VisibleSpecificControls(Boolean val)
        {
            btnPrevious.Visible = val;
            btnNext.Visible = val;
        }
        private void VisibleButtons(Boolean val)
        {
            btnSave.Visible = val;
            btnEdit.Visible = !val;
        }
        private void ResetControls()
        {

            txtCategory.Text = "";
            txtDesc.Text = "";
            lblCategoryCode.Text = "";
        }


        private bool ValidateAll()
        {
            bool IsValid = true;
            if (txtCategory.Text == string.Empty)
            {
                eprError.SetError(txtCategory, objMsg.GetDisplayMessage(0, 3));
                IsValid = false;
            }
            else
            {
                eprError.SetError(txtCategory, "");
            }
            


            return IsValid;
        }

        private void SaveData()
        {
            objProp.CategoryName = txtCategory.Text.Trim();
            objProp.CategoryDesc = txtDesc.Text.Trim();

            if (OperType == OperationType.Add)
            {
                objBACL.AddCategory(objProp);
                if (objProp.ErrorOccured == true)
                    return;

                lblCategoryCode.Text = objProp.CategoryCode.ToString();
                ResetControls();

            }
            else if (OperType == OperationType.Edit)
            {
                objProp.CategoryCode = Convert.ToInt32(lblCategoryCode.Text);
                objBACL.EditCategory(objProp);
                if (objProp.ErrorOccured == true)
                    return;
                EnableControls(false);
                VisibleButtons(false);

            }


        }
        private void MapToScreenFields(CategoryProp objProp)
        {
            if (objProp.CategoryCode > 0)
            {

                txtCategory.Text = objProp.CategoryName;
                txtDesc.Text = objProp.CategoryDesc;
                 lblCategoryCode.Text = objProp.CategoryCode.ToString();
            }
        }


    }
}
