﻿using ShopperStock.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static ShopperStock.Model.UtilEnum;

namespace ShopperStock.UI_Forms
{
    public partial class Customer : Form
    {
        private readonly UtilityFunction objutilFun = new UtilityFunction();
        private readonly MessageBL objMsg = new MessageBL();
        private readonly CustomerBACL objBACL = new CustomerBACL();
        private readonly CustomerProp objProp = new CustomerProp();
        private  OperationType OperType;
        public Customer()
        {
            InitializeComponent();
        }
        private void Customer_Load(object sender, EventArgs e)
        {
            OperType = GlobalVariables.gblOperType;
            objProp.PLCode = GlobalVariables.gblRecordID;

            if (OperType == OperationType.Add)    //Modifications
            {
                VisibleSpecificControls(false);
                EnableControls(true);
                VisibleButtons(true);
            }
            if (OperType == OperationType.View)    //Modifications
            {
                DisplayFromDB();
                EnableControls(false);
                VisibleSpecificControls(true);
                VisibleButtons(false);
            }
            txtPartyName.Select();
        }
        private void BtnNext_Click(object sender, EventArgs e)
        {
            objProp.PLCode = Convert.ToInt32(lblPLCode.Text) + 1;
            if (OperType == OperationType.View)    //Modifications
            {
                DisplayFromDB();
                EnableControls(false);
                VisibleSpecificControls(true);
                VisibleButtons(false);
            }
            if (OperType == OperationType.Edit)    //Modifications
            {
                DisplayFromDB();
                EnableControls(true);
                VisibleSpecificControls(true);
                VisibleButtons(true);
                txtPartyName.Select();
            }
        }

        private void BtnPrevious_Click(object sender, EventArgs e)
        {
            objProp.PLCode = Convert.ToInt32(lblPLCode.Text) - 1;
            if (OperType == OperationType.View)    //Modifications
            {
                DisplayFromDB();
                EnableControls(false);
                VisibleSpecificControls(true);
                VisibleButtons(false);
            }
            if (OperType == OperationType.Edit)    //Modifications
            {
                DisplayFromDB();
                EnableControls(true);
                VisibleSpecificControls(true);
                VisibleButtons(true);
                txtPartyName.Select();
            }
        }

        private void BtnEdit_Click(object sender, EventArgs e)
        {
            OperType = OperationType.Edit;
            EnableControls(true);
            VisibleSpecificControls(true);
            VisibleButtons(true);
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            if (ValidateAll() == false)
                return;

            SaveData();
            if (objProp.ErrorOccured == true)
            {
                MessageBox.Show(objMsg.GetDisplayMessage(0, 0), Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                MessageBox.Show(objMsg.GetDisplayMessage(0, 4), Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        protected override bool ProcessDialogKey(Keys keyData)
        {
            if (Form.ModifierKeys == Keys.None && keyData == Keys.Escape)
            {
                this.Close();
                return true;
            }
            return base.ProcessDialogKey(keyData);
        }

       

     

       

        private void TxtAddress1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtAddress2.Select();
            }
        }

        private void TxtAddress2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtCity.Select();
            }
        }

        private void TxtCity_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtState.Select();
            }
        }

        private void TxtState_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtPIN.Select();
            }
        }

        private void TxtPIN_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtPhone.Select();
            }
        }

        private void TxtPhone_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                BtnSave_Click(sender, e);
            }
        }



        private void TxtPartyName_KeyPress(object sender, KeyPressEventArgs e)
        {
              if (!char.IsLetter(e.KeyChar) && (e.KeyChar != Convert.ToChar(Keys.Space)) && (e.KeyChar != '(') && (e.KeyChar != ')') && (e.KeyChar != ',') && (e.KeyChar != '-') && (e.KeyChar != '&') && (e.KeyChar != '.') && e.KeyChar != Convert.ToChar(Keys.Back) && e.KeyChar != Convert.ToChar(Keys.Delete))
            {
                e.Handled = true;
            }

        }

        private void TxtPIN_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != Convert.ToChar(Keys.Back) && e.KeyChar != Convert.ToChar(Keys.Delete))
            {
                e.Handled = true;
            }
        }

        private void TxtPhone_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && (e.KeyChar != Convert.ToChar(Keys.Space)) && (e.KeyChar != ',') && (e.KeyChar != ',') && e.KeyChar != Convert.ToChar(Keys.Back) && e.KeyChar != Convert.ToChar(Keys.Delete))
            {
                e.Handled = true;
            }
        }
        private void BtnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtEmail_Leave(object sender, EventArgs e)
        {
            if (txtEmail.Text.Trim() != string.Empty)
            {
                if (!IsValidMail(txtEmail.Text.Trim()))
                {
                    eprError.SetError(txtEmail, objMsg.GetDisplayMessage(0, 2));
                }
                else
                {
                    eprError.SetError(txtEmail, "");
                }
            }
            else
            {
                eprError.SetError(txtEmail, "");
            }
        }
        private void EnableControls(Boolean val)
        {
            txtPartyName.Enabled = val;

            txtAddress1.Enabled = val;
            txtAddress2.Enabled = val;
            txtCity.Enabled = val;
            txtState.Enabled = val;
            txtPIN.Enabled = val;
            txtPhone.Enabled = val;
            lblPLCode.Enabled = val;
            txtEmail.Enabled = val;

        }


        private void DisplayFromDB()
        {

            CustomerProp objNewProp = objBACL.GetCustomer(objProp);
            if (objNewProp.ErrorOccured == true)
            {
                MessageBox.Show(objMsg.GetDisplayMessage(0, 0), Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            MapToScreenFields(objNewProp);
        }
        private void VisibleSpecificControls(Boolean val)
        {
            btnPrevious.Visible = val;
            btnNext.Visible = val;
        }
        private void VisibleButtons(Boolean val)
        {
            btnSave.Visible = val;
            btnEdit.Visible = !val;
        }
        private void ResetControls()
        {
            txtPartyName.Text = "";
            txtAddress1.Text = "";
            txtAddress2.Text = "";
            txtCity.Text = "";
            txtState.Text = "";
            txtPIN.Text = "";
            txtPhone.Text = "";
            lblPLCode.Text = "";
            txtEmail.Text = "";
        }


        private bool ValidateAll()
        {
            bool IsValid = true;
            if (txtPartyName.Text == string.Empty)
            {
                eprError.SetError(txtPartyName, objMsg.GetDisplayMessage(0, 3));
                IsValid = false;
            }
            else
            {
                eprError.SetError(txtPartyName, "");
            }
            if (txtAddress1.Text == string.Empty)
            {
                eprError.SetError(txtAddress1, objMsg.GetDisplayMessage(0, 3));
                IsValid = false;
            }
            else
            {
                eprError.SetError(txtAddress1, "");
            }

            return IsValid;
        }

        private void SaveData()
        {
            objProp.PLName = txtPartyName.Text.Trim(); 
            objProp.PLAddress1 = txtAddress1.Text.Trim();
            objProp.PLAddress2 = txtAddress2.Text.Trim();
            objProp.PLCity = txtCity.Text.Trim();
            objProp.PLState = txtState.Text.Trim();
            objProp.PLEmail = txtEmail.Text.Trim();

            if (txtPIN.Text == string.Empty)
            {
                objProp.PLPIN = 0;
            }
            else
            {
                objProp.PLPIN = Convert.ToInt32(txtPIN.Text);
            }
            objProp.PLPhone = txtPhone.Text.Trim();


            if (OperType == OperationType.Add)
            {
                objBACL.AddCustomer(objProp);
                if (objProp.ErrorOccured == true)
                    return;

                lblPLCode.Text = objProp.PLCode.ToString();
                ResetControls();

            }
            else if (OperType == OperationType.Edit)
            {
                objProp.PLCode = Convert.ToInt32(lblPLCode.Text);
               objBACL.EditCustomer(objProp);
                if (objProp.ErrorOccured == true)
                    return;
                EnableControls(false);
                VisibleButtons(false);

            }


        }
        private void MapToScreenFields(CustomerProp objProp)
        {
            if (objProp.PLCode > 0)
            {
                txtPartyName.Text = objProp.PLName;
                txtAddress1.Text = objProp.PLAddress1;
                txtAddress2.Text = objProp.PLAddress2;
                txtCity.Text = objProp.PLCity;
                txtState.Text = objProp.PLState;
                txtEmail.Text = objProp.PLEmail;
                if (objProp.PLPIN == 0)
                    txtPIN.Text = "";
                else
                    txtPIN.Text = Convert.ToString(objProp.PLPIN);
                txtPhone.Text = objProp.PLPhone;

                lblPLCode.Text = Convert.ToString(objProp.PLCode);
            }
        }
        public bool IsValidMail(string emailaddress)
        {
            try
            {
                MailAddress m = new MailAddress(emailaddress);

                return true;
            }
            catch (FormatException)
            {
                return false;
            }
        }

    }
}
