﻿using ShopperStock.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static ShopperStock.Model.UtilEnum;

namespace ShopperStock.UI_Forms
{
    public partial class Lookup : Form
    {
        private readonly MessageBL objMsg = new MessageBL();
        private LookUpType CurrentLookUpType;
        public Lookup()
        {
            InitializeComponent();
        }

        private void Lookup_Load(object sender, EventArgs e)
        {
            ResetControls();
            SetPrimaryData();

            LoadGridData();

          if ( dgvData.DataSource!=null)
            SetGridStyle();
            txtLookUpText.Select();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            String ColName = dgvData.Columns[1].Name;

            if (txtLookUpText.Text == String.Empty)
                (dgvData.DataSource as DataTable).DefaultView.RowFilter = "";
            else
                (dgvData.DataSource as DataTable).DefaultView.RowFilter = string.Format("[{0}] LIKE '%{1}%'", ColName, txtLookUpText.Text);

        }

        private void dgvData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1)
                return;

            if (e.ColumnIndex == dgvData.ColumnCount - 1)
            {
                GlobalVariables.LookUpCode = dgvData.Rows[e.RowIndex].Cells[0].Value.ToString();
                GlobalVariables.LookUpName = dgvData.Rows[e.RowIndex].Cells[1].Value.ToString();
                GlobalVariables.LookUpPartyCode = dgvData.Rows[e.RowIndex].Cells[0].Value.ToString();
                GlobalVariables.LookUpPartyName = dgvData.Rows[e.RowIndex].Cells[1].Value.ToString();
                this.Close();
            }
        }

        private void dgvData_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1)
                return;

            GlobalVariables.LookUpCode = dgvData.Rows[e.RowIndex].Cells[0].Value.ToString();
            GlobalVariables.LookUpName = dgvData.Rows[e.RowIndex].Cells[1].Value.ToString();

            GlobalVariables.LookUpPartyCode = dgvData.Rows[e.RowIndex].Cells[0].Value.ToString();
            GlobalVariables.LookUpPartyName = dgvData.Rows[e.RowIndex].Cells[1].Value.ToString();

            this.Close();
        }
        private void ResetControls()
        {
            txtLookUpText.Text = "";

            dgvData.DataSource = null;
        }

        private void SetPrimaryData()
        {
            CurrentLookUpType = GlobalVariables.LookUpType;

            this.Text = CurrentLookUpType + " Look Up";
        }

        private void SetGridStyle()
        {
            dgvData.AutoGenerateColumns = true;
            dgvData.Font = new Font("Verdana", 9);
            dgvData.ReadOnly = true;
            dgvData.AllowUserToAddRows = false; //To delete the last emty row in the grid

            dgvData.Columns[0].Visible = false;     //First column will be ID                       

            DataGridViewLinkColumn SelectLink = new DataGridViewLinkColumn();
            SelectLink.UseColumnTextForLinkValue = true;
            SelectLink.HeaderText = "Select";
            SelectLink.DataPropertyName = "lnkColumn";
            SelectLink.LinkBehavior = LinkBehavior.SystemDefault;
            SelectLink.Text = "Select";
            dgvData.Columns.Add(SelectLink);

            for (int i = 0; i < dgvData.Columns.Count; i++)
            {
                dgvData.Columns[i].Width =  250;
            }

        }

        private void LoadGridData()
        {
            DataTable ds = new DataTable();

            if (CurrentLookUpType == LookUpType.Category)
                ds = GetCategory();

            if (CurrentLookUpType == LookUpType.Party)
                ds = LoadParty();

            if (CurrentLookUpType == LookUpType.Product)
                ds = LoadProduct();

            if (ds != null  && ds.Rows.Count > 0)
            {
                dgvData.DataSource = ds;
            }
        }

        private DataTable GetCategory()
        {
     
            ProductProp objProductProp = new ProductProp();
            ProductBACL objProductBACL = new ProductBACL();

            DataTable ds = objProductBACL.GetCategory(objProductProp);

            if (objProductProp.ErrorOccured == true)
            {
                MessageBox.Show(objMsg.GetDisplayMessage(0, 0), Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return ds;
        }
        private DataTable LoadParty()
        {

            CustomerProp objProductProp = new CustomerProp();
            CustomerBACL objProductBACL = new CustomerBACL();

            DataTable ds = objProductBACL.GetAllCustomer(objProductProp);

            if (objProductProp.ErrorOccured == true)
            {
                MessageBox.Show(objMsg.GetDisplayMessage(0, 0), Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return ds;
        }

        private DataTable LoadProduct()
        {
            ProductProp objNewProp = new ProductProp();
            ProductBACL objNewBACL = new ProductBACL();
            DataTable dt = objNewBACL.GetAllProduct(objNewProp);
            if (objNewProp.ErrorOccured == true)
            {
                MessageBox.Show(objMsg.GetDisplayMessage(0, 5), Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return dt;
        }
        protected override bool ProcessDialogKey(Keys keyData)
        {
            if (Form.ModifierKeys == Keys.None && keyData == Keys.Escape)
            {
                this.Close();
                return true;
            }
            return base.ProcessDialogKey(keyData);
        }

        private void TxtLookUpText_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (  e.KeyChar != ',' && e.KeyChar != '.')
            {
                btnSearch_Click(sender, e);
            }

        }
    }
}
