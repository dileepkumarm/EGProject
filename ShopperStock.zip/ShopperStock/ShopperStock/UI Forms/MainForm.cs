﻿using ShopperStock.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static ShopperStock.Model.UtilEnum;

namespace ShopperStock.UI_Forms
{
    public partial class frmMainForm : Form
    {
        public frmMainForm()
        {
            InitializeComponent();
        }
        private void MainForm_Load(object sender, EventArgs e)
        {
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


        private void CategoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mnCategory frm = new mnCategory();
            frm.ShowDialog();

        }

        private void productToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mnProduct frm = new mnProduct();
            frm.ShowDialog();
        }


        private void salesBillToolStripMenuItem_Click(object sender, EventArgs e)
        {

            SalesBill frm = new SalesBill();
            frm.ShowDialog();
        }


        private void CustomerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mnCustomer frm = new mnCustomer();
            frm.ShowDialog();
        }

        private void btnSalesBill_Click(object sender, EventArgs e)
        {
            paymentmode frm = new paymentmode();
            frm.ShowDialog();
        }



    }
}
