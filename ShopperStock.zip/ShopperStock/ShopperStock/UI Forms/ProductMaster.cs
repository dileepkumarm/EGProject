﻿using ShopperStock.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static ShopperStock.Model.UtilEnum;

namespace ShopperStock.UI_Forms
{
    public partial class ProductMaster : Form
    {
        private readonly MessageBL objMsg = new MessageBL();
        private readonly ProductBACL objBACL = new ProductBACL();
        private readonly ProductProp objProp = new ProductProp();
        private OperationType OperType;
        public ProductMaster()
        {
            InitializeComponent();
        }
        private void ProductMaster_Load(object sender, EventArgs e)
        {
            OperType = GlobalVariables.gblOperType;
            objProp.ProductCode = GlobalVariables.gblRecordID;

            if (OperType == OperationType.Add)    //Modifications
            {
                VisibleSpecificControls(false);
                EnableControls(true);
                VisibleButtons(true);
                ResetControls();
            }
            if (OperType == OperationType.View)    //Modifications
            {
                DisplayFromDB();
                EnableControls(false);
                VisibleSpecificControls(true);
                VisibleButtons(false);
            }
            txtProductName.Select();
        }
        private void btnPrevious_Click(object sender, EventArgs e)
        {
            objProp.ProductCode = Convert.ToInt32(lblProductCode.Text) - 1;
            if (OperType == OperationType.View)    //Modifications
            {
                DisplayFromDB();
                EnableControls(false);
                VisibleSpecificControls(true);
                VisibleButtons(false);
            }
            if (OperType == OperationType.Edit)    //Modifications
            {
                DisplayFromDB();
                EnableControls(true);
                VisibleSpecificControls(true);
                VisibleButtons(true);
                txtProductName.Select();
            }
        }
        private void btnEdit_Click(object sender, EventArgs e)
        {
            OperType = OperationType.Edit;
            EnableControls(true);
            VisibleSpecificControls(true);
            VisibleButtons(true);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ValidateAll() == false)
                return;

            SaveData();
            if (objProp.ErrorOccured == true)
            {
                MessageBox.Show(objMsg.GetDisplayMessage(0, 0), Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                MessageBox.Show(objMsg.GetDisplayMessage(0, 4), Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void btnNext_Click(object sender, EventArgs e)
        {
            objProp.ProductCode = Convert.ToInt32(lblProductCode.Text) + 1;
            if (OperType == OperationType.View)    //Modifications
            {
                DisplayFromDB();
                EnableControls(false);
                VisibleSpecificControls(true);
                VisibleButtons(false);
            }
            if (OperType == OperationType.Edit)    //Modifications
            {
                DisplayFromDB();
                EnableControls(true);
                VisibleSpecificControls(true);
                VisibleButtons(true);
                txtProductName.Select();
            }
        }
        private void btnSearch_Click(object sender, EventArgs e)
        {
            GlobalVariables.LookUpType = LookUpType.Category;

            Lookup frm = new Lookup();
            frm.ShowDialog();

            DisplayCategoryData();
        }



        private void TxtSalesRate_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && (e.KeyChar != '.') && e.KeyChar != Convert.ToChar(Keys.Back) && e.KeyChar != Convert.ToChar(Keys.Delete))
            {
                e.Handled = true;
            }
        }



        private void TxtQty_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && (e.KeyChar != '.') && e.KeyChar != Convert.ToChar(Keys.Back) && e.KeyChar != Convert.ToChar(Keys.Delete))
            {
                e.Handled = true;
            }
        }






        protected override bool ProcessDialogKey(Keys keyData)
        {
            if (Form.ModifierKeys == Keys.None && keyData == Keys.Escape)
            {
                this.Close();
                return true;
            }
            return base.ProcessDialogKey(keyData);
        }

        private void EnableControls(Boolean val)
        {
            txtProductName.Enabled = val;

            txtSalesRate.Enabled = val;
            txtQty.Enabled = val;
            txtProductDesc.Enabled = val;
            lblProductCode.Enabled = val;
            btnSearch.Enabled = val;
            txtCategoryCode.Enabled = val;

        }



        private void DisplayFromDB()
        {

            ProductProp objNewProp = objBACL.GetProduct(objProp);
            if (objNewProp.ErrorOccured == true)
            {
                MessageBox.Show(objMsg.GetDisplayMessage(0, 0), Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            MapToScreenFields(objNewProp);
        }

        private void DisplayCategoryData()
        {
            if (GlobalVariables.LookUpCode != string.Empty)
            {
                lblCategoryCode.Text = GlobalVariables.LookUpCode.ToString();
            }
            else
            {
                lblCategoryCode.Text = "0";
            }

            txtCategoryCode.Text = GlobalVariables.LookUpName;
        }
        private void VisibleSpecificControls(Boolean val)
        {
            btnPrevious.Visible = val;
            btnNext.Visible = val;
        }
        private void VisibleButtons(Boolean val)
        {
            btnSave.Visible = val;
            btnEdit.Visible = !val;
        }
        private void ResetControls()
        {
            txtProductName.Text = "";
            txtSalesRate.Text = "0";
            txtQty.Text = "0";
            lblProductCode.Text = "";
            lblCategoryCode.Text = "";
            txtProductDesc.Text = "";
            txtCategoryCode.Text = "";
        }


        private bool ValidateAll()
        {
            bool IsValid = true;
            if (txtProductName.Text == string.Empty)
            {
                eprError.SetError(txtProductName, objMsg.GetDisplayMessage(0, 3));
                IsValid = false;
            }
            else
            {
                eprError.SetError(txtProductName, "");
            }


            return IsValid;
        }

        private void SaveData()
        {

            objProp.ProductName = txtProductName.Text.Trim();
            objProp.ProductSalesRate = Convert.ToDecimal(txtSalesRate.Text);
            objProp.ProductQty = Convert.ToInt32(txtQty.Text);
            objProp.ProductCategoryCode = lblCategoryCode.Text;
            objProp.ProductDesc = txtProductDesc.Text;
            if (OperType == OperationType.Add)
            {
                objBACL.AddProduct(objProp);
                if (objProp.ErrorOccured == true)
                    return;

                ResetControls();

            }
            else if (OperType == OperationType.Edit)
            {
                objProp.ProductCode = Convert.ToInt32(lblProductCode.Text);
                objBACL.EditProduct(objProp);
                if (objProp.ErrorOccured == true)
                    return;
                EnableControls(false);
                VisibleButtons(false);

            }


        }
        private void MapToScreenFields(ProductProp objProp)
        {
            if (objProp.ProductCode > 0)
            {

                lblProductCode.Text = Convert.ToString(objProp.ProductCode);
                txtProductName.Text = objProp.ProductName;
                txtProductDesc.Text = objProp.ProductDesc;
                txtQty.Text = objProp.ProductQty.ToString();
                txtCategoryCode.Text = objProp.ProductCategoryName;
                lblCategoryCode.Text = objProp.ProductCategoryCode;
                txtSalesRate.Text = Convert.ToString(objProp.ProductSalesRate);

            }
        }

        
    }
}
