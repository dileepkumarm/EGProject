﻿using ShopperStock.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static ShopperStock.Model.UtilEnum;

namespace ShopperStock.UI_Forms
{
    public partial class SalesBill : Form
    {
        private readonly MessageBL objMsg = new MessageBL();
        private readonly SalesBillBACL objBACL = new SalesBillBACL();
        private readonly SalesBillProp objProp = new SalesBillProp();

        private OperationType OperType;
        public SalesBill()
        {
            InitializeComponent();
        }

        protected override bool ProcessDialogKey(Keys keyData)
        {
            if (Form.ModifierKeys == Keys.None && keyData == Keys.Escape)
            {
                this.Close();
                return true;
            }
            return base.ProcessDialogKey(keyData);
        }

        private void BtnExit_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void SalesBill_Load(object sender, EventArgs e)
        {
                lblPageName.Text = "Sales Bill";


            OperType = GlobalVariables.gblOperType;
            objProp.SBMastCode = GlobalVariables.gblRecordID;
            ResetControls();
            if (OperType == OperationType.Add)    //Modifications
            {
                EnableControls(true);
                VisibleButtons(true);
                
            }
            txtPartyName.Select();
        }


        private void VisibleButtons(Boolean val)
        {
            btnSave.Visible = val;
        }
        private void ResetControls()
        {

            txtPartyName.Text = "";
            lblPartyCode.Text = "";
            txtDisc.Text = "0";
            txtInvoiceTotal.Text = "0";
            txtProductName.Text = "";
            txtQty.Text = "0";
            txtSalesRate.Text = "0";
            txtTax.Text = "0";
            lblProductCode.Text = "";
            lblSalesBillCode.Text = "0";
        }
        private void EnableControls(Boolean val)
        {

            txtPartyName.Enabled = val;
            btnSearch.Enabled = val;
            txtPartyName.Enabled = val;
            txtDisc.Enabled = val;
            txtInvoiceTotal.Enabled = val;
            txtProductName.Enabled = val;
            txtQty.Enabled = val;
            txtSalesRate.Enabled = val;
            txtTax.Enabled = val;


        }


        private bool ValidateAll()
        {
            bool IsValid = true;
            if (txtPartyName.Text == string.Empty)
            {
                eprError.SetError(txtPartyName, objMsg.GetDisplayMessage(0, 3));
                IsValid = false;
            }
            else
            {
                eprError.SetError(txtPartyName, "");
            }
            if (txtProductName.Text == string.Empty)
            {
                eprError.SetError(txtProductName, objMsg.GetDisplayMessage(0, 3));
                IsValid = false;
            }
            else
            {
                eprError.SetError(txtPartyName, "");
            }
            if (txtQty.Text == string.Empty)
            {
                eprError.SetError(txtQty, objMsg.GetDisplayMessage(0, 3));
                IsValid = false;
            }
            else
            {
                eprError.SetError(txtPartyName, "");
            }
            if (txtSalesRate.Text == string.Empty)
            {
                eprError.SetError(txtSalesRate, objMsg.GetDisplayMessage(0, 3));
                IsValid = false;
            }
            else
            {
                eprError.SetError(txtPartyName, "");
            }
           
            return IsValid;
        }
        private void SaveData()
        {
              objProp.SBMastPartyID = lblPartyCode.Text;
             objProp.SBMastProductCode = Convert.ToInt32(lblProductCode.Text);
            objProp.SBMastDisc = Convert.ToDecimal(txtDisc.Text);
            objProp.SBMastInvoiceAmt = Convert.ToDecimal(txtInvoiceTotal.Text);
            objProp.SBMastQty = Convert.ToInt32(txtQty.Text);
            objProp.SBMastSalesRate = Convert.ToDecimal(txtSalesRate.Text);
            objProp.SBMastTax = Convert.ToDecimal(txtTax.Text);
            objProp.SBMastPartyName = txtPartyName.Text;
            objProp.SBMastProductName = txtProductName.Text;
            if (OperType == OperationType.Add)
            {
                objBACL.AddSales(objProp);
                if (objProp.ErrorOccured == true)
                    return;

                ResetControls();
   
            }

        }


        private void button3_Click(object sender, EventArgs e)
        {
            GlobalVariables.LookUpType = LookUpType.Party;

            Lookup frm = new Lookup();
            frm.ShowDialog();

            DisplayPartyData();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            GlobalVariables.LookUpType = LookUpType.Product;

            Lookup frm = new Lookup();
            frm.ShowDialog();

            DisplayProductData();
        }

        private void DisplayPartyData()
        {
            if (GlobalVariables.LookUpCode != string.Empty)
            {
                lblPartyCode.Text = GlobalVariables.LookUpPartyCode.ToString();
            }
            else
            {
                lblPartyCode.Text = "0";
            }

            txtPartyName.Text = GlobalVariables.LookUpPartyName;
        }

        private void DisplayProductData()
        {
            if (GlobalVariables.LookUpCode != string.Empty)
            {
                lblProductCode.Text = GlobalVariables.LookUpCode.ToString();
            }
            else
            {
                lblProductCode.Text = "0";
            }

            txtProductName.Text = GlobalVariables.LookUpName;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            OperType = OperationType.Edit;
            EnableControls(true);
            VisibleButtons(true);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (ValidateAll() == false)
                return;

            SaveData();
            if (objProp.ErrorOccured == true)
            {
                MessageBox.Show(objMsg.GetDisplayMessage(0, 0), Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {

                DialogResult dialogResult = MessageBox.Show("Redirecting to the payment page", "Invoice Payment", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    paymentmode frm = new paymentmode();
                    frm.ShowDialog();

                }
            }
        }

        private void txtQty_Leave(object sender, EventArgs e)
        {
            InvoiceTotal();
        }

        private void txtSalesRate_Leave(object sender, EventArgs e)
        {
            InvoiceTotal();
        }



        private void txtDisc_Leave(object sender, EventArgs e)
        {
            InvoiceTotal();
        }

        private void txtTax_Leave(object sender, EventArgs e)
        {
            InvoiceTotal();
        }


        private void InvoiceTotal()
        {
            double Amt = 0, Tax = 0, DiscAmt = 0, DiscRate = 0, Qty = 0;

            Qty = Convert.ToDouble(txtQty.Text);
            Amt = Qty * Convert.ToDouble(txtSalesRate.Text);
            DiscAmt = Amt * 0.01 * Convert.ToDouble(txtDisc.Text);
            Tax = (Amt - DiscAmt) * (0.01 * Convert.ToDouble(txtTax.Text));
            txtInvoiceTotal.Text = ((Amt - DiscAmt) + (Tax)).ToString();
        }

    }
}
