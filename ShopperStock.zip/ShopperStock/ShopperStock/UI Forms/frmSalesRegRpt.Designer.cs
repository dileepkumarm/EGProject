﻿namespace ShopperStock.UI_Forms
{
    partial class frmSalesRegRpt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSalesRegRpt));
            this.PnlDailySales = new System.Windows.Forms.Panel();
            this.btnView = new System.Windows.Forms.Button();
            this.dteBillDate = new System.Windows.Forms.DateTimePicker();
            this.lblBillDate = new System.Windows.Forms.Label();
            this.dteRecieveDate = new System.Windows.Forms.DateTimePicker();
            this.lblRecieveDate = new System.Windows.Forms.Label();
            this.PnlDailySales.SuspendLayout();
            this.SuspendLayout();
            // 
            // PnlDailySales
            // 
            this.PnlDailySales.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PnlDailySales.Controls.Add(this.btnView);
            this.PnlDailySales.Controls.Add(this.dteBillDate);
            this.PnlDailySales.Controls.Add(this.lblBillDate);
            this.PnlDailySales.Controls.Add(this.dteRecieveDate);
            this.PnlDailySales.Controls.Add(this.lblRecieveDate);
            this.PnlDailySales.Location = new System.Drawing.Point(4, 4);
            this.PnlDailySales.Name = "PnlDailySales";
            this.PnlDailySales.Size = new System.Drawing.Size(308, 202);
            this.PnlDailySales.TabIndex = 0;
            // 
            // btnView
            // 
            this.btnView.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnView.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnView.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnView.ForeColor = System.Drawing.Color.White;
            this.btnView.Image = global::ShopperStock.Properties.Resources.Open_in_new_white_24dp_1x;
            this.btnView.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnView.Location = new System.Drawing.Point(105, 125);
            this.btnView.Name = "btnView";
            this.btnView.Size = new System.Drawing.Size(114, 40);
            this.btnView.TabIndex = 10;
            this.btnView.Text = "  Preview";
            this.btnView.UseVisualStyleBackColor = false;
            this.btnView.Click += new System.EventHandler(this.btnView_Click);
            // 
            // dteBillDate
            // 
            this.dteBillDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dteBillDate.Location = new System.Drawing.Point(105, 23);
            this.dteBillDate.Name = "dteBillDate";
            this.dteBillDate.Size = new System.Drawing.Size(140, 20);
            this.dteBillDate.TabIndex = 48;
            // 
            // lblBillDate
            // 
            this.lblBillDate.AutoSize = true;
            this.lblBillDate.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Bold);
            this.lblBillDate.ForeColor = System.Drawing.Color.DimGray;
            this.lblBillDate.Location = new System.Drawing.Point(18, 26);
            this.lblBillDate.Name = "lblBillDate";
            this.lblBillDate.Size = new System.Drawing.Size(59, 17);
            this.lblBillDate.TabIndex = 51;
            this.lblBillDate.Text = "From :";
            // 
            // dteRecieveDate
            // 
            this.dteRecieveDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dteRecieveDate.Location = new System.Drawing.Point(107, 61);
            this.dteRecieveDate.Name = "dteRecieveDate";
            this.dteRecieveDate.Size = new System.Drawing.Size(138, 20);
            this.dteRecieveDate.TabIndex = 49;
            // 
            // lblRecieveDate
            // 
            this.lblRecieveDate.AutoSize = true;
            this.lblRecieveDate.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Bold);
            this.lblRecieveDate.ForeColor = System.Drawing.Color.DimGray;
            this.lblRecieveDate.Location = new System.Drawing.Point(38, 61);
            this.lblRecieveDate.Name = "lblRecieveDate";
            this.lblRecieveDate.Size = new System.Drawing.Size(39, 17);
            this.lblRecieveDate.TabIndex = 50;
            this.lblRecieveDate.Text = "To :";
            // 
            // frmSalesRegRpt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(316, 209);
            this.Controls.Add(this.PnlDailySales);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmSalesRegRpt";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sales Register";
            this.PnlDailySales.ResumeLayout(false);
            this.PnlDailySales.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel PnlDailySales;
        private System.Windows.Forms.DateTimePicker dteBillDate;
        private System.Windows.Forms.Label lblBillDate;
        private System.Windows.Forms.DateTimePicker dteRecieveDate;
        private System.Windows.Forms.Label lblRecieveDate;
        private System.Windows.Forms.Button btnView;
    }
}