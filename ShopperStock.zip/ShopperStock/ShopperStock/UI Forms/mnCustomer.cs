﻿using ShopperStock.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static ShopperStock.Model.UtilEnum;

namespace ShopperStock.UI_Forms
{
    public partial class mnCustomer : Form
    {
        private DataView DVeiwDet;
        private readonly CustomerBACL objBACL = new CustomerBACL();
        private readonly CustomerProp objProp = new CustomerProp();
        private readonly UtilityFunction objutilFun = new UtilityFunction();
        private readonly MessageBL objMsg = new MessageBL();
        public mnCustomer()
        {
            InitializeComponent();
        }
        private void mnCustomer_Load(object sender, EventArgs e)
        {
            LoadStaticData();
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void btnNew_Click(object sender, EventArgs e)
        {
            Customer frm = new Customer();
            GlobalVariables.gblOperType = OperationType.Add;
            frm.ShowDialog();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {

            DataSet ds = GetSearchQueryData();
            if (objProp.ErrorOccured == true)
            {
                MessageBox.Show(objMsg.GetDisplayMessage(0, 5), Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            LoadListViewData(ds);
        }
        private void tsmViewDetails_Click(object sender, EventArgs e)
        {
            if (lvwData.FocusedItem != null)
            {
                Customer frm = new Customer();
                GlobalVariables.gblOperType = OperationType.View;
                GlobalVariables.gblRecordID = Convert.ToInt32(lvwData.FocusedItem.Text);
                frm.ShowDialog();
            }
        }
        private void cbxSearch_SelectedIndexChanged(object sender, EventArgs e)
        {
            ResetSearchControls();
            switch (cbxSearch.SelectedIndex)
            {
                case 1:
                    txtSearch.Visible = true;
                    break;
            }


        }
        protected override bool ProcessDialogKey(Keys keyData)
        {
            if (Form.ModifierKeys == Keys.None && keyData == Keys.Escape)
            {
                this.Close();
                return true;
            }
            return base.ProcessDialogKey(keyData);
        }


        private void ResetSearchControls()
        {
            txtSearch.Visible = false;
            txtSearch.Text = "";
        }
        private void LoadStaticData()
        {
            LoadSearchOptions();
        }
        private void LoadSearchOptions()
        {
            Dictionary<String, String> List = new Dictionary<String, String>();

            Array enumValues;
            enumValues = Enum.GetValues(typeof(CustomerSearch));
            foreach (Enum value in enumValues)
            {
                List.Add(value.GetHashCode().ToString(), objutilFun.GetEnumDescription(value));
            }

            // Bind the combo box 
            cbxSearch.ValueMember = "Key";
            cbxSearch.DisplayMember = "Value";
            cbxSearch.DataSource = new BindingSource(List, null);
        }



        private DataSet GetSearchQueryData()
        {

            objProp.SearchIndex = Convert.ToInt32(cbxSearch.SelectedValue);
            objProp.SearchText = txtSearch.Text.Trim();

            DataSet ds = objBACL.GetCustomerSearchQueryData(objProp);
            return ds;
        }

        private void LoadListViewData(DataSet ds)
        {

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
                DVeiwDet = ds.Tables[0].DefaultView;

            lvwData.Items.Clear();

            this.Cursor = Cursors.WaitCursor;

            for (int i = 0; i <= DVeiwDet.Count - 1; i++)
            {
                String RecordNo = Convert.ToString(DVeiwDet[i]["PLCode"]);     //Record No
                ListViewItem item = new ListViewItem(RecordNo);
                ListViewItem.ListViewSubItem sub1 = new ListViewItem.ListViewSubItem(item, DVeiwDet[i]["PLName"] == null ? string.Empty : DVeiwDet[i]["PLName"].ToString());     //PersonnelName
                item.SubItems.Add(sub1);
                ListViewItem.ListViewSubItem sub3 = new ListViewItem.ListViewSubItem(item, DVeiwDet[i]["PLAddress1"] == null ? string.Empty : DVeiwDet[i]["PLAddress1"].ToString());     //ContactNo
                item.SubItems.Add(sub3);
                ListViewItem.ListViewSubItem sub4 = new ListViewItem.ListViewSubItem(item, DVeiwDet[i]["PLAddress2"] == null ? string.Empty : DVeiwDet[i]["PLAddress2"].ToString());     //EmployeeName
                item.SubItems.Add(sub4);
                ListViewItem.ListViewSubItem sub5 = new ListViewItem.ListViewSubItem(item, DVeiwDet[i]["PLCity"] == null ? string.Empty : DVeiwDet[i]["PLCity"].ToString());     //CompanyName
                item.SubItems.Add(sub5);
                ListViewItem.ListViewSubItem sub6 = new ListViewItem.ListViewSubItem(item, DVeiwDet[i]["PLPhone"] == null ? string.Empty : DVeiwDet[i]["PLPhone"].ToString());     //SupervisorName
                item.SubItems.Add(sub6);
                ListViewItem.ListViewSubItem sub7 = new ListViewItem.ListViewSubItem(item, DVeiwDet[i]["PLEmail"] == null ? string.Empty : DVeiwDet[i]["PLEmail"].ToString());     //SupervisorName
                item.SubItems.Add(sub7);
                lvwData.Items.Add(item);
            }

            this.Cursor = Cursors.Default;
        }

        private void TxtSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnSearch_Click(sender, e);
            }
        }

        private void deleteCustomerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (lvwData.FocusedItem != null)
            {
                objProp.PLCode = Convert.ToInt32(lvwData.FocusedItem.Text);
                objBACL.DeleteCustomer(objProp) ;
                if (objProp.ErrorOccured == true)
                {
                    MessageBox.Show(objMsg.GetDisplayMessage(0, 0), Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else
                {
                    MessageBox.Show(objMsg.GetDisplayMessage(0, 5), Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    btnSearch_Click(sender, e);
                }
            }
        }
    }
}
