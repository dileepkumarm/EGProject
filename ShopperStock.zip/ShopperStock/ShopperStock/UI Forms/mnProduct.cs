﻿using ShopperStock.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static ShopperStock.Model.UtilEnum;

namespace ShopperStock.UI_Forms
{
    public partial class mnProduct : Form
    {
        private  DataView DVeiwDet;
        private readonly ProductBACL objBACL = new ProductBACL();
        private readonly ProductProp objProp = new ProductProp();
        private readonly UtilityFunction objutilFun = new UtilityFunction();
        private readonly MessageBL objMsg = new MessageBL();
        public mnProduct()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            ProductMaster frm = new ProductMaster();
            GlobalVariables.gblOperType = OperationType.Add;
            frm.ShowDialog();
        }
        protected override bool ProcessDialogKey(Keys keyData)
        {
            if (Form.ModifierKeys == Keys.None && keyData == Keys.Escape)
            {
                this.Close();
                return true;
            }
            return base.ProcessDialogKey(keyData);
        }

        private void mnProduct_Load(object sender, EventArgs e)
        {
            LoadStaticData();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {

            DataSet ds = GetSearchQueryData();
            if (objProp.ErrorOccured == true)
            {
                MessageBox.Show(objMsg.GetDisplayMessage(0, 5), Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            LoadListViewData(ds);
        }

        private void tsmViewDetails_Click(object sender, EventArgs e)
        {
            if (lvwData.FocusedItem != null)
            {
                ProductMaster frm = new ProductMaster();
                GlobalVariables.gblOperType = OperationType.View;
                GlobalVariables.gblRecordID = Convert.ToInt32(lvwData.FocusedItem.Text);
                frm.ShowDialog();
            }
        }

        private void cbxSearch_SelectedIndexChanged(object sender, EventArgs e)
        {
            ResetSearchControls();
            switch (cbxSearch.SelectedIndex)
            {
                case 1:
                    txtSearch.Visible = true;
                    break;
            }


        }
        private void txtSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnSearch_Click(sender, e);
            }
        }
        private void ResetSearchControls()
        {
            txtSearch.Visible = false;
            txtSearch.Text = "";
        }
        private void LoadStaticData()
        {
            LoadSearchOptions();
        }
        private void LoadSearchOptions()
        {
            Dictionary<String, String> List = new Dictionary<String, String>();

            Array enumValues;
            enumValues = Enum.GetValues(typeof(ProductSearch));
            foreach (Enum value in enumValues)
            {
                List.Add(value.GetHashCode().ToString(), objutilFun.GetEnumDescription(value));
            }

            // Bind the combo box 
            cbxSearch.ValueMember = "Key";
            cbxSearch.DisplayMember = "Value";
            cbxSearch.DataSource = new BindingSource(List, null);
        }



        private DataSet GetSearchQueryData()
        {

            objProp.SearchIndex = Convert.ToInt32(cbxSearch.SelectedValue);
            objProp.SearchText = txtSearch.Text.Trim();

            DataSet ds = objBACL.GetProductSearchQueryData(objProp);
            return ds;
        }

        private void LoadListViewData(DataSet ds)
        {

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
                DVeiwDet = ds.Tables[0].DefaultView;

            lvwData.Items.Clear();

            this.Cursor = Cursors.WaitCursor;

            for (int i = 0; i <= DVeiwDet.Count - 1; i++)
            {
                String RecordNo = Convert.ToString(DVeiwDet[i]["ProductCode"]);     //Record No
                ListViewItem item = new ListViewItem(RecordNo);
                ListViewItem.ListViewSubItem sub1 = new ListViewItem.ListViewSubItem(item, DVeiwDet[i]["ProductName"] == null ? string.Empty : DVeiwDet[i]["ProductName"].ToString());     //PersonnelName
                item.SubItems.Add(sub1);
                ListViewItem.ListViewSubItem sub2 = new ListViewItem.ListViewSubItem(item, DVeiwDet[i]["ProductSalesRate"] == null ? string.Empty : DVeiwDet[i]["ProductSalesRate"].ToString());     //ContactNo
                item.SubItems.Add(sub2);
                ListViewItem.ListViewSubItem sub4 = new ListViewItem.ListViewSubItem(item, DVeiwDet[i]["ProductCategoryName"] == null ? string.Empty : DVeiwDet[i]["ProductCategoryName"].ToString());     //PersonnelCategoryName
                item.SubItems.Add(sub4);
                ListViewItem.ListViewSubItem sub5 = new ListViewItem.ListViewSubItem(item, DVeiwDet[i]["ProductQty"] == null ? string.Empty : DVeiwDet[i]["ProductQty"].ToString());     //CompanyName
                item.SubItems.Add(sub5);
                ListViewItem.ListViewSubItem sub6 = new ListViewItem.ListViewSubItem(item, DVeiwDet[i]["ProductName"] == null ? string.Empty : DVeiwDet[i]["ProductName"].ToString());     //CompanyName
                item.SubItems.Add(sub6);
                lvwData.Items.Add(item);
            }

            this.Cursor = Cursors.Default;

        }

        private void editProductToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (lvwData.FocusedItem != null)
            {
                ProductMaster frm = new ProductMaster();
                GlobalVariables.gblOperType = OperationType.Edit;
                GlobalVariables.gblRecordID = Convert.ToInt32(lvwData.FocusedItem.Text);
                frm.ShowDialog();
            }
        }

        private void deleteProductToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (lvwData.FocusedItem != null)
            {
                objProp.ProductCode = Convert.ToInt32(lvwData.FocusedItem.Text);
                objBACL.DeleteProduct(objProp);
                if (objProp.ErrorOccured == true)
                {
                    MessageBox.Show(objMsg.GetDisplayMessage(0, 0), Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else
                {
                    MessageBox.Show(objMsg.GetDisplayMessage(0, 5), Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    btnSearch_Click(sender, e);
                }
            }
        }
    }
}
