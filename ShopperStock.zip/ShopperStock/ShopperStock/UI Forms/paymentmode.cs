﻿using ShopperStock.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static ShopperStock.Model.UtilEnum;

namespace ShopperStock.UI_Forms
{
    public partial class paymentmode : Form
    {
        private readonly MessageBL objMsg = new MessageBL();
        public paymentmode()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            if (ValidateAll() == false)
                return;
            //implement payments logic
            MessageBox.Show(objMsg.GetDisplayMessage(0, 6), Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);

            DialogResult dialogResult = MessageBox.Show(objMsg.GetDisplayMessage(0, 7), Application.ProductName, MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                MessageBox.Show(objMsg.GetDisplayMessage(0, 8), Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);

            }

        }

        protected override bool ProcessDialogKey(Keys keyData)
        {
            if (Form.ModifierKeys == Keys.None && keyData == Keys.Escape)
            {
                this.Close();
                return true;
            }
            return base.ProcessDialogKey(keyData);
        }


        private void MnSalesBill_Load(object sender, EventArgs e)
        {
            ResetCardControls(false);
            ResetVPControls(false);
            ResetNetBankingControls(false);
        }


        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                ResetCardControls(false);
                ResetVPControls(true);
                ResetNetBankingControls(false);
            }
        }
        private void ResetNetBankingControls(bool val)
        {
            textBox5.Visible = val;
            textBox6.Visible = val;
            textBox7.Visible = val;
            label5.Visible = val;
            label6.Visible = val;
            label7.Visible = val;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked)
            {
                ResetCardControls(true);
                ResetVPControls(false);
                ResetNetBankingControls(false);
            }
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton3.Checked)
            {
                ResetCardControls(false);
                ResetVPControls(false);
                ResetNetBankingControls(true);
            }
        }
        private void ResetCardControls(bool val)
        {
            textBox1.Visible = val;
            textBox2.Visible = val;
            textBox3.Visible = val;
            label1.Visible = val;
            label2.Visible = val;
            label3.Visible = val;
        }
        private void ResetVPControls(bool val)
        {
            textBox4.Visible = val;
            label4.Visible = val;

        }
        private bool ValidateAll()
        {
            bool IsValid = true;
            if (textBox8.Text == string.Empty)
            {
                eprError.SetError(textBox8, objMsg.GetDisplayMessage(0, 3));
                IsValid = false;
            }
            else
            {
                eprError.SetError(textBox8, "");
            }
            if(radioButton1.Checked)
            {
                if (textBox4.Text == string.Empty)
                {
                    eprError.SetError(textBox4, objMsg.GetDisplayMessage(0, 3));
                    IsValid = false;
                }
                else
                {
                    eprError.SetError(textBox4, "");
                }

            }
            if (radioButton2.Checked)
            {
                if (textBox1.Text == string.Empty)
                {
                    eprError.SetError(textBox1, objMsg.GetDisplayMessage(0, 3));
                    IsValid = false;
                }
                else
                {
                    eprError.SetError(textBox1, "");
                }
                if (textBox2.Text == string.Empty)
                {
                    eprError.SetError(textBox2, objMsg.GetDisplayMessage(0, 3));
                    IsValid = false;
                }
                else
                {
                    eprError.SetError(textBox2, "");
                }
                if (textBox3.Text == string.Empty)
                {
                    eprError.SetError(textBox3, objMsg.GetDisplayMessage(0, 3));
                    IsValid = false;
                }
                else
                {
                    eprError.SetError(textBox3, "");
                }
            }
            if (radioButton3.Checked)
            {
                if (textBox5.Text == string.Empty)
                {
                    eprError.SetError(textBox5, objMsg.GetDisplayMessage(0, 3));
                    IsValid = false;
                }
                else
                {
                    eprError.SetError(textBox5, "");
                }
                if (textBox6.Text == string.Empty)
                {
                    eprError.SetError(textBox6, objMsg.GetDisplayMessage(0, 3));
                    IsValid = false;
                }
                else
                {
                    eprError.SetError(textBox6, "");
                }
                if (textBox7.Text == string.Empty)
                {
                    eprError.SetError(textBox7, objMsg.GetDisplayMessage(0, 3));
                    IsValid = false;
                }
                else
                {
                    eprError.SetError(textBox7, "");
                }
            }
            return IsValid;
        }
    }
}
